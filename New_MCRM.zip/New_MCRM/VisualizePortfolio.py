import pandas as pd
import matplotlib.pyplot as plt

# 读取数据
data = pd.read_excel('对比策略结果/AEC(IMCRM).xlsx', index_col='Stock', parse_dates=True)
#data = data.T
industry_data = pd.read_excel('/结果分析/ESG分析/esg_industry.xlsx', index_col='Stock')
merged_data = pd.merge(data, industry_data, left_index=True, right_index=True)
print(merged_data)

plt.figure(figsize=(12, 8))
for industry, group in merged_data.groupby('Industry'):
    group.drop('Industry', axis=1).T.plot(label=industry)

plt.title('Stock Investment Over Time by Industry')
plt.xlabel('Date')
plt.ylabel('Investment Ratio')
plt.legend(title='Industry')
plt.show()
'''
data.plot(kind='box', figsize=(10, 6))
plt.title('Distribution of Stock Investment Ratios')
plt.ylabel('Investment Ratio')
plt.show()
'''

