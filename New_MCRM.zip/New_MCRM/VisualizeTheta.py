import pandas as pd
import matplotlib.pyplot as plt
import seaborn as sns
import os
import numpy as np
from matplotlib import rcParams
config = {
            "font.family": 'serif',
            "font.size": 10,# 相当于小四大小
            "mathtext.fontset": 'stix',#matplotlib渲染数学字体时使用的字体，和Times New Roman差别不大
            "font.serif": ['Songti SC'],#宋体
            'axes.unicode_minus': False # 处理负号，即-号
         }
rcParams.update(config)

def Visualize_theta_all_strategies():
    all_data_noindex = pd.read_excel('修正/改变theta的累积收益/cumulative_wealth_theta.xlsx')
    all_data = all_data_noindex.set_index('策略')
    #all_data = all_data.reindex(sorted(all_data.index, key=lambda x: x), axis=0)  # 对列进行排序，以确保图例的顺序按照数字顺序

    # 绘制热力图
    fig, ax = plt.subplots(figsize=(10, 4))
    sns.heatmap(all_data, annot=True, fmt=".4f", cmap='YlOrRd', ax=ax, cbar_kws={'pad': 0.01})
    ax.set_xlabel('\u03B8', labelpad=5)
    ax.set_ylabel('Strategy', labelpad=5)
    ax.set_yticklabels(all_data_noindex['策略'].tolist(), va='center', rotation=90)
    ax.xaxis.set_ticks_position('none')
    ax.yaxis.set_ticks_position('none')
    #ax.set_aspect(1)
    plt.title(f'Cumulative Wealth with \u03BB Changed')
    #plt.show()
    plt.savefig('修正/改变theta的累积收益/改变theta的累积收益(所有策略).png',dpi=600)
    plt.close()

def Visualize_theta_AEC():
    df_theta_noindex = pd.read_excel('修正/改变theta的累积收益/cumulative_wealth_theta.xlsx')[:2]
    df_theta = df_theta_noindex.set_index('策略')
    fig, ax = plt.subplots(figsize=(10, 4))
    sns.heatmap(df_theta, annot=True, fmt=".4f", cmap='YlOrRd', ax=ax, cbar_kws={"shrink": 0.7, 'pad': 0.01})
    ax.set_xlabel('\u03B8', labelpad=5)
    #ax.set_ylabel(None, labelpad=8)
    ylabel = df_theta_noindex['策略'].tolist()
    ax.set_yticklabels(ylabel, va='center', rotation=90)
    ax.xaxis.set_ticks_position('none')
    ax.yaxis.set_ticks_position('none')
    #plt.title(f'Cumulative Wealth with \u03B8 Changed')
    ax.set_aspect(1)
    # plt.show()
    plt.savefig('修正/改变theta的累积收益/改变theta的累积收益(AEC).png', dpi=600)
    plt.close()

#Visualize_theta_AEC()
Visualize_theta_all_strategies()
