import pandas as pd
import numpy as np
from scipy.optimize import minimize
import datetime
import os
import glob

# 计算轮盘赌的平均累积收益
def AverageAEC():
    folder_path = "改变轮盘赌lambda动态状态转移矩阵0-1的累积收益"  
    files = [f for f in os.listdir(folder_path) if f.endswith('.xlsx')]  # 获取文件夹中的所有文件
    folder_path_old = 'MCRM/改变轮盘赌lambda动态状态转移矩阵0-1的累积收益'
    files_old = [f for f in os.listdir(folder_path_old) if f.endswith('.xlsx')]
    all_data = pd.DataFrame()
    all_data_old = pd.DataFrame()

    # 遍历文件夹中的每个文件
    for file in files:
        data = pd.read_excel(os.path.join(folder_path, file))
        lambda_value = round(float(file.split('_')[-1].rstrip('.xlsx')), 1)  # 从文件名中提取lambda的值
        all_data[lambda_value] = data['累积收益']  # 将累积收益列添加到all_data DataFrame中，列名为lambda的值
        all_data['Date'] = data['Date']
    for file in files_old:
        data = pd.read_excel(os.path.join(folder_path_old, file))
        lambda_value = round(float(file.split('_')[-1].rstrip('.xlsx')), 1)  # 从文件名中提取lambda的值
        all_data_old[lambda_value] = data['累积收益']  # 将累积收益列添加到all_data DataFrame中，列名为lambda的值
        all_data_old['Date'] = data['Date']
    all_data['平均值'] = all_data.mean(axis=1)  # 计算所有结果的平均值，并添加到DataFrame中
    all_data_old['平均值'] = all_data_old.mean(axis=1)  # 计算所有结果的平均值，并添加到DataFrame中
    all_data_new = pd.DataFrame()
    all_data_new['Date'] = all_data['Date']
    all_data_new['累积收益'] = all_data['平均值']
    all_data_old_new = pd.DataFrame()
    all_data_old_new['Date'] = all_data_old['Date']
    all_data_old_new['累积收益'] = all_data_old['平均值']
    all_data_new.to_excel('累积收益/cumulative_wealth(AEC(IMCRM)).xlsx',index=False)
    all_data_old_new.to_excel('累积收益/cumulative_wealth(AEC(SMCRM)).xlsx',index=False)

# 计算累积收益
def culculate_cumulative_wealth(strategy_portfolio):
    portfolio_allocation = pd.read_excel(f"对比策略结果/{strategy_portfolio}.xlsx")  # 最优投资组合（每只股票）
    portfolio_allocation.columns = [col if isinstance(col, datetime.datetime) or col == 'Stock' else datetime.datetime.strptime(col,'%Y/%m/%d') for col in
                                    portfolio_allocation.columns]
    cumulative_time = portfolio_allocation.shape[1]
    theta = 0.0005  # 交易成本率

    cumulative_wealth_df = pd.DataFrame(columns=['Date', '累积收益'])  # 存每天的累积收益
    k_df = pd.DataFrame(columns=['Date', 'k'])  # 存每天的真实资产比例
    S_tminus1 = 1
    b_tminus1_tilde = np.zeros(50)
    for t in range(2, cumulative_time):  # 遍历每个交易日
        date = portfolio_allocation.columns[t]  # t时刻的日期
        x_t = returns_df.loc[:, date]  # 所有股票t时刻的相对价格

        b_t = portfolio_allocation.iloc[:, t]  # 所有股票t时刻的分配比例
        b_tminus1 = portfolio_allocation.iloc[:, t - 1]  # 所有股票t-1时刻的分配比例

        # 解交易成本k的目标函数v
        def objective_function(k):
            l1_norm = np.sum(np.abs(b_tminus1_tilde - b_t * k))
            return 1 - k - theta * l1_norm

        constraint = (
        {'type': 'ineq', 'fun': lambda k: 1e-20 - np.abs(1 - k - theta * np.sum(np.abs(b_tminus1_tilde - b_t * k)))})
        k = minimize(objective_function, 1, bounds=[(0, 1)], constraints=constraint).x
        s_t = S_tminus1 * k * (np.dot(b_t, x_t))  # 考虑成本损失的累计收益
        S_tminus1 = s_t
        b_tminus1_tilde = b_t * x_t / (np.dot(b_t, x_t))
        print(f"{date}的累积财富为:{s_t[0]}")
        cumulative_wealth_df = cumulative_wealth_df.append({'Date': date, '累积收益': s_t[0]}, ignore_index=True)
    cumulative_wealth_df.to_excel(f"累积收益/cumulative_wealth({strategy_portfolio}).xlsx", index=False)
    #k_df.to_excel(f"交易成本/实际资产比例({strategy_portfolio}).xlsx", index=False)
    #print(cumulative_wealth_df)
    return cumulative_wealth_df

def calculate_metrics(strategy_portfolio):
    risk_free_rate = 1
    cumulative_wealth = pd.read_excel(f"累积收益/cumulative_wealth({strategy_portfolio}).xlsx")['累积收益']
    returns = cumulative_wealth.div(cumulative_wealth.shift())
    returns = returns.fillna(1)
    real_returns = returns - 1

    # 计算最大回撤（MDD）
    drawdowns = np.minimum(real_returns - 1, 0)  # 只考虑收益小于1的情况
    MDD = np.sqrt(np.mean(drawdowns ** 2))  # 根据公式计算MDD

    # 计算VaR
    confidence_level = 0.95
    VaR = - np.percentile(real_returns, 100*(1-confidence_level))

    # 计算CVaR
    CVaR = - np.mean(real_returns[real_returns < - VaR])

    # 计算超额收益
    excess_returns = returns - benchmark_returns

    # 计算Beta, Alpha
    Beta = returns.cov(benchmark_returns) / np.var(benchmark_returns)
    Alpha = np.mean(returns)- [risk_free_rate + Beta*(np.mean(benchmark_returns) - risk_free_rate)]

    # 计算夏普比率
    sharpe_ratio = (np.mean(returns) - risk_free_rate) / np.std(returns)

    # 计算信息比率
    information_ratio = np.mean(excess_returns) / np.std(excess_returns)

    # 计算卡玛比率
    calmar_ratio = (np.mean(returns) - risk_free_rate) / MDD

    # 计算特雷诺比率
    Treynor_ratio = (np.mean(returns) - risk_free_rate) / Beta

    # 计算M2比率
    M2_ratio =(np.mean(returns) - risk_free_rate) * (np.std(benchmark_returns) / np.std(returns)) - (np.mean(benchmark_returns) - risk_free_rate)

    return {
        '策略': strategy_portfolio,
        'VaR': VaR,
        'CVaR': CVaR,
        'MDD': MDD,
        'Beta': Beta,
        'Alpha': Alpha[0],
        'Sharp ratio': sharpe_ratio,
        'Information ratio': information_ratio,
        'Calmar ratio': calmar_ratio,
        'Treynor ratio': Treynor_ratio,
        'M2 ration': M2_ratio,
    }

if __name__ == '__main__':
    #AverageAEC()
    # 获取每种策略的结果文件
    strategy_portfolio_files = [os.path.basename(file) for file in glob.glob(os.path.join('对比策略结果/', '*'))]
    strategy_portfolios = [file.split('.')[0] for file in strategy_portfolio_files]

    returns_df = pd.read_excel("returns.xlsx") # 读取收益率数据
    returns_df.replace(0, np.nan, inplace=True)
    returns_df.bfill(inplace=True)

    # 计算每种策略的累积收益
    all_cumulative_wealth = pd.DataFrame() # 保存全部策略的累积收益
    for strategy in strategy_portfolios:
        '''
        if strategy == 'AEC(IMCRM)':
            cumulative_wealth_df = pd.read_excel('累积收益/cumulative_wealth(AEC(IMCRM)).xlsx')
        elif strategy == 'AEC(SMCRM)':
            cumulative_wealth_df = pd.read_excel('累积收益/cumulative_wealth(AEC(SMCRM)).xlsx')
        else:
            #cumulative_wealth_df = culculate_cumulative_wealth(strategy)
        '''
        cumulative_wealth_df = pd.read_excel(f'累积收益/cumulative_wealth({strategy}).xlsx')
        cumulative_wealth_df.rename(columns={'累积收益': strategy}, inplace=True)

        if all_cumulative_wealth.empty:
            all_cumulative_wealth = cumulative_wealth_df
        else:
            all_cumulative_wealth = pd.merge(all_cumulative_wealth, cumulative_wealth_df, on='Date', how='left')

    all_cumulative_wealth = pd.DataFrame()  # 保存全部策略的累积收益
    for strategy in strategy_portfolios:
        cumulative_wealth_df = pd.read_excel(f'累积收益/cumulative_wealth({strategy}).xlsx')
        cumulative_wealth_df.rename(columns={'累积收益': strategy}, inplace=True)
        if all_cumulative_wealth.empty:
            all_cumulative_wealth = cumulative_wealth_df
        else:
            all_cumulative_wealth = pd.merge(all_cumulative_wealth, cumulative_wealth_df, on='Date', how='left')

    #all_cumulative_wealth.to_excel("所有策略的累积收益-动态转移矩阵0-1.xlsx", index=False)
    # 重新排序
    strategy_order_df = pd.read_excel("/Users/yinmengzi/Desktop/策略.xlsx")
    strategy_order = strategy_order_df['策略'].tolist()

    all_cumulative_wealth = all_cumulative_wealth[['Date'] + strategy_order]
    all_cumulative_wealth.reset_index(drop=True).to_excel(f'EvaluateResults-Dynamic01.xlsx', index=False)

    # benchmark的每日收益向量
    cumulative_wealth = pd.read_excel(f"累积收益/cumulative_wealth(BAH).xlsx")['累积收益']
    benchmark_returns = cumulative_wealth.div(cumulative_wealth.shift())

    # 计算每种策略的评价指标
    metrics_df = pd.DataFrame() # 保存全部策略的评价指标
    for strategy in strategy_portfolios:
        metrics = calculate_metrics(strategy)
        metrics_df = metrics_df.append(metrics, ignore_index=True)
    # 重新排序
    order_df = pd.read_excel('策略.xlsx')
    order = order_df['策略'].tolist()
    metrics_df['策略'] = pd.Categorical(metrics_df['策略'], categories=order, ordered=True)
    metrics_df.sort_values(by='策略', inplace=True)
    metrics_df.reset_index(drop=True).to_excel('EvaluateResults-Dynamic01.xlsx', index=False)
