import pandas as pd
import matplotlib.pyplot as plt
import seaborn as sns
import os
import numpy as np
import matplotlib.dates as mdates
from matplotlib import rcParams
config = {
            "font.family": 'serif',
            "font.size": 10,# 相当于小四大小
            "mathtext.fontset": 'stix',#matplotlib渲染数学字体时使用的字体，和Times New Roman差别不大
            "font.serif": ['Songti SC'],#宋体
            'axes.unicode_minus': False # 处理负号，即-号
         }
rcParams.update(config)

folder_path = "改变lambda的累积收益" # 文件夹路径
files = [f for f in os.listdir(folder_path) if f.endswith('.xlsx')] # 获取文件夹中的所有文件

def Visualize_lambda_line():
    all_data = pd.DataFrame()  # 创建一个空的DataFrame来存储所有的数据
    # 遍历文件夹中的每个文件
    for file in files:
        data = pd.read_excel(os.path.join(folder_path, file))
        lambda_value = round(float(file.split('_')[-1].rstrip('.xlsx')),1) # 从文件名中提取lambda的值
        all_data[lambda_value] = data['累积收益'] # 将累积收益列添加到all_data DataFrame中，列名为lambda的值

    all_data = all_data.reindex(sorted(all_data.columns, key=lambda x:float(x)), axis=1) # 对列进行排序，以确保图例的顺序按照数字顺序

    all_data['Date'] = pd.to_datetime(data['Date'])
    all_data.set_index('Date', inplace=True)
    all_data['平均值'] = all_data.mean(axis=1) # 计算所有结果的平均值，并添加到DataFrame中
    print(all_data)
    #绘制折线图
    fig, ax = plt.subplots(figsize=(10, 6))
    colors = plt.cm.viridis(np.linspace(0, 1, len(all_data.columns))) # 创建一个颜色映射
    for i, column in enumerate(all_data.columns):
        ax.plot(all_data.index,all_data[column], color=colors[i], label=column)
    ax.xaxis.set_major_formatter(mdates.DateFormatter('%Y/%m'))
    ax.xaxis.set_major_locator(mdates.MonthLocator(bymonth=[2, 8]))  # x轴每3个月显示
    plt.title('Cumulative Wealth with \u03BB Changed')
    plt.xlabel('Date')
    plt.ylabel('Cumulative Wealth')
    plt.grid(False)
    plt.legend(loc='upper left')
    plt.savefig('改变lambda的累积收益/改变lambda的累积收益（折线图）.png',dpi=600)
    plt.close()

def Visualize_lambda_heat():
    all_data = pd.DataFrame()  # 创建一个空的DataFrame来存储所有的数据
    for file in files:
        data = pd.read_excel(os.path.join(folder_path, file))
        lambda_value = round(float(file.split('_')[-1].rstrip('.xlsx')),1) # 从文件名中提取lambda的值
        all_data.loc[lambda_value,'Cumulative Wealth'] = data.iloc[-1]['累积收益']  # 将累积收益列添加到all_data DataFrame中，列名为lambda的值

    all_data = all_data.reindex(sorted(all_data.index, key=lambda x: x), axis=0)  # 对列进行排序，以确保图例的顺序按照数字顺序

    # 绘制热力图
    fig, ax = plt.subplots(figsize=(10, 4))
    sns.heatmap(all_data.T, annot=True, fmt=".4f", cmap='YlOrRd', ax=ax, yticklabels=False)
    ax.set_xlabel('L', labelpad=5)
    ax.set_ylabel('Cumulative Wealth', labelpad=10)
    ax.xaxis.set_ticks_position('none')
    ax.yaxis.set_ticks_position('none')
    plt.title(f'Cumulative Wealth with \u03BB Changed')
    #plt.show()
    plt.savefig('改变lambda的累积收益/改变lambda的累积收益（热力图）.png',dpi=600)
    plt.close()

Visualize_lambda_line()
#Visualize_lambda_heat()