import pandas as pd
import numpy as np
from scipy.optimize import minimize
import datetime
import os
import glob

# 计算累积收益
def culculate_cumulative_wealth(strategy_portfolio):
    portfolio_allocation = pd.read_excel(f"对比策略结果/{strategy_portfolio}.xlsx")  # 最优投资组合（每只股票）
    portfolio_allocation.columns = [col if isinstance(col, datetime.datetime) or col == 'Stock' else datetime.datetime.strptime(col,'%Y/%m/%d') for col in
                                    portfolio_allocation.columns]
    cumulative_time = portfolio_allocation.shape[1]
    theta = 0.0005  # 交易成本率

    cumulative_wealth_df = pd.DataFrame(columns=['Date', '累积收益'])  # 存每天的累积收益
    k_df = pd.DataFrame(columns=['Date', 'k'])  # 存每天的真实资产比例
    S_tminus1 = 1

    cumulative_wealth_df = cumulative_wealth_df.append({'Date': portfolio_allocation.columns[1], '累积收益': S_tminus1}, ignore_index=True)
    k_df = k_df.append({'Date': portfolio_allocation.columns[1].strftime('%Y/%m/%d'), 'k': 1}, ignore_index=True)

    for t in range(2, cumulative_time): # 遍历每个交易日
        date = portfolio_allocation.columns[t]  # t时刻的日期
        x_t = returns_df.loc[:, date]  # 所有股票t时刻的相对价格

        b_t = portfolio_allocation.iloc[:, t]  # 所有股票t时刻的分配比例
        b_tminus1 = portfolio_allocation.iloc[:, t-1] # 所有股票t-1时刻的分配比例

        # 解交易成本k的目标函数
        def objective_function(k, b_tminus1, b_t, theta):
            l1_norm = np.sum(np.abs(b_tminus1 - b_t * k))
            return 1 - k - theta * l1_norm
        k = minimize(objective_function, 1, args=(b_tminus1, b_t, theta), bounds=[(0, 1)]).x  # 考虑交易成本，实际资产比例
        s_t = S_tminus1 * k * (np.dot(b_t.T, x_t))  # 考虑成本损失的累计收益
        S_tminus1 = s_t

        print(f"{date}的累积财富为:{s_t[0]}")
        cumulative_wealth_df = cumulative_wealth_df.append({'Date': date, '累积收益': s_t[0]}, ignore_index=True)
        k_df = k_df.append({'Date': date, 'k': k[0]}, ignore_index=True)

    cumulative_wealth_df.to_excel(f"累积财富/cumulative_wealth({strategy_portfolio}).xlsx", index=False)
    k_df.to_excel(f"交易成本/实际资产比例({strategy_portfolio}).xlsx", index=False)
    return cumulative_wealth_df

def calculate_metrics(strategy_portfolio):
    risk_free_rate = 1
    portfolio_allocation = pd.read_excel(f"对比策略结果/{strategy_portfolio}.xlsx").set_index('Stock')  # 最优投资组合（每只股票）
    portfolio_allocation.columns = pd.to_datetime(portfolio_allocation.columns).strftime('%Y/%m/%d')  # 修改时间格式，保证一致
    k_df = pd.read_excel(f'交易成本/实际资产比例({strategy_portfolio}).xlsx').set_index('Date') # 考虑成本的实际资产
    k_df.index = pd.to_datetime(BAH_k_df.index).strftime('%Y/%m/%d')  # 修改时间格式，保证一致
    cumulative_wealth = pd.read_excel(f"累积财富/cumulative_wealth({strategy_portfolio}).xlsx").iloc[-1]['累积收益']

    # 计算每日收益向量
    returns = returns_df_index.multiply(portfolio_allocation).sum(axis=0).multiply(k_df['k']) # 向量，每日的收益b_t * x_t
    real_returns = real_returns_df.multiply(portfolio_allocation).sum(axis=0).multiply(k_df['k']) # 向量，每日的收益率[(pi-pi-1)/pi-1] * x_t

    # 计算年均收益
    #y = len(returns) / 252
    #APY = cumulative_wealth**(1/y) -1

    # 计算最大回撤（MDD）
    drawdowns = np.minimum(returns - 1, 0)  # 只考虑收益小于1的情况
    MDD = np.sqrt(np.mean(drawdowns ** 2))  # 根据公式计算MDD

    # 计算VaR
    confidence_level = 0.95
    VaR = - np.percentile(real_returns, 100*(1-confidence_level))

    # 计算CVaR
    CVaR = - np.mean(real_returns[real_returns < - VaR])

    # 计算超额收益
    excess_returns = returns - benchmark_returns

    # 计算Beta, Alpha
    Beta = returns.cov(benchmark_returns) / np.var(benchmark_returns)
    Alpha = np.mean(returns)- [risk_free_rate + Beta*(np.mean(benchmark_returns) - risk_free_rate)]

    # 计算夏普比率
    sharpe_ratio = (np.mean(returns) - risk_free_rate) / np.std(returns)

    # 计算信息比率
    information_ratio = np.mean(excess_returns) / np.std(excess_returns)

    # 计算卡玛比率
    calmar_ratio = (np.mean(returns) - risk_free_rate) / MDD

    # 计算特雷诺比率
    Treynor_ratio = (np.mean(returns) - risk_free_rate) / Beta

    # 计算M2比率
    M2_ratio =(np.mean(returns) - risk_free_rate) * (np.std(benchmark_returns) / np.std(returns)) - (np.mean(benchmark_returns) - risk_free_rate)

    # 索提诺比率
    Downside_deviation = np.std(returns - np.ones(len(returns))) # 下行偏差
    Sortino_ratio = (np.mean(returns) - risk_free_rate) / Downside_deviation

    return {
        '策略': strategy_portfolio,
        #'APY': APY,
        'VaR': VaR,
        'CVaR': CVaR,
        'MDD': MDD,
        'Beta': Beta,
        'Alpha': Alpha[0],
        'Sharp ratio': sharpe_ratio,
        'Information ratio': information_ratio,
        'Calmar ratio': calmar_ratio,
        'Treynor ratio': Treynor_ratio,
        'M2 ration': M2_ratio,
        'Sortino ratio': Sortino_ratio
    }

if __name__ == '__main__':
    returns_df = pd.read_excel("returns.xlsx")  # 读取收益率数据x=pi/pi-1
    time_gap = returns_df.shape[1]
    real_returns_df = pd.read_excel("realreturns.xlsx").set_index('Stock').iloc[:, 30:]  # 读取收益率数据x=(pi-pi-1)/pi-1
    real_returns_df.columns = pd.to_datetime(real_returns_df.columns).strftime('%Y/%m/%d')  # 修改时间格式，保证一致

    # 获取每种策略的结果文件
    strategy_portfolio_files = [os.path.basename(file) for file in glob.glob(os.path.join('对比策略结果/', '*'))]
    strategy_portfolios = [file.split('.')[0] for file in strategy_portfolio_files]
    # 计算每种策略的累积收益

    all_cumulative_wealth = pd.DataFrame() # 保存全部策略的累积收益
    for strategy in strategy_portfolios:
        cumulative_wealth_df = culculate_cumulative_wealth(strategy)
        cumulative_wealth_df.rename(columns={'累积收益': strategy}, inplace=True)

        if all_cumulative_wealth.empty:
            all_cumulative_wealth = cumulative_wealth_df
        else:
            all_cumulative_wealth = pd.merge(all_cumulative_wealth, cumulative_wealth_df, on='Date', how='left')

    all_cumulative_wealth.to_excel("所有策略的累积收益.xlsx", index=False)

    # benchmark的每日收益向量
    BAH_k_df = pd.read_excel('交易成本/实际资产比例(BAH).xlsx').set_index('Date')
    BAH_k_df.index = pd.to_datetime(BAH_k_df.index).strftime('%Y/%m/%d') # 修改时间格式，保证一致
    benchmark_portfolio_allocation = pd.read_excel('对比策略结果/BAH.xlsx').set_index('Stock')
    benchmark_portfolio_allocation.columns = pd.to_datetime(benchmark_portfolio_allocation.columns).strftime('%Y/%m/%d') # 修改时间格式，保证一致
    returns_df_index = returns_df.set_index("Stock").iloc[:,30:]
    returns_df_index.columns = pd.to_datetime(returns_df_index.columns).strftime('%Y/%m/%d') # 修改时间格式，保证一致
    benchmark_returns_no_cost = returns_df_index.multiply(benchmark_portfolio_allocation).sum(axis=0)
    benchmark_returns = benchmark_returns_no_cost.multiply(BAH_k_df['k'])

    # 计算每种策略的评价指标
    metrics_df = pd.DataFrame() # 保存全部策略的评价指标
    for strategy in strategy_portfolios:
        metrics = calculate_metrics(strategy)
        metrics_df = metrics_df.append(metrics, ignore_index=True)
    metrics_df.to_excel('所有策略评估结果.xlsx', index=False)