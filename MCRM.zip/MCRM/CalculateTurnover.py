# -*- coding: utf-8 -*-
# @Time    : 2024/9/5 9:24 上午
# @Author  : Mengzi Yin
# @FileName: CalculateTurnover.py
# @Software: PyCharm

import pandas as pd
import datetime
import numpy as np
from scipy.optimize import minimize
import pandas as pd
import matplotlib.pyplot as plt
import seaborn as sns
from sympy import latex,symbols
import os
from matplotlib import rcParams
config = {
            "font.family": 'serif',
            "font.size": 10,# 相当于小四大小
            "mathtext.fontset": 'stix',#matplotlib渲染数学字体时使用的字体，和Times New Roman差别不大
            "font.serif": ['Songti SC'],#宋体
            'axes.unicode_minus': False # 处理负号，即-号
         }
rcParams.update(config)
'''
# 读取收益率数据
returns_df = pd.read_excel("returns.xlsx")
returns_df.replace(0, np.nan, inplace=True)
returns_df.bfill(inplace=True)
metrics_df = pd.DataFrame()
theta = 0.0005
L_values = [0.01,0.1, 0.5, 1, 10]
ETA_values = [0, 0.005, 0.01, 0.1, 0.5, 1, 10]
for L in L_values:
    for eta in ETA_values:
            portfolio_allocation = pd.read_excel(f'改变eta、L的投资组合/MyAEC_eta{eta}_L{L}.xlsx')
            if 'index' in portfolio_allocation.columns:
                portfolio_allocation = portfolio_allocation.drop('index', axis=1)
            portfolio_allocation.columns = [col if isinstance(col, datetime.datetime) or col == 'Stock' else datetime.datetime.strptime(col, '%Y/%m/%d') for col in portfolio_allocation.columns]
            cumulative_time = portfolio_allocation.shape[1]

            cumulative_wealth_df = pd.DataFrame(columns=['Date', '累积收益'])  # 存每天的累积收益
            k_df = pd.DataFrame(columns=['Date', 'k'])  # 存每天的真实资产比例
            s_t = 0
            for t in range(2, cumulative_time):  # 遍历每个交易日
                date = portfolio_allocation.columns[t]  # t时刻的日期
                x_t = returns_df.loc[:, date]  # 所有股票t时刻的相对价格

                b_t = portfolio_allocation.iloc[:, t]  # 所有股票t时刻的分配比例
                b_tminus1 = portfolio_allocation.iloc[:, t - 1]  # 所有股票t-1时刻的分配比例

                # 解交易成本k的目标函数
                def objective_function(k):
                    l1_norm = np.sum(np.abs(b_tminus1 - b_t * k))
                    return 1 - k - theta * l1_norm

                # 定义距离约束
                constraint = (
                {'type': 'ineq', 'fun': lambda k: 1e-20 - np.abs(1 - k - theta * np.sum(np.abs(b_tminus1 - b_t * k)))})
                k = minimize(objective_function, 1, bounds=[(0, 1)], constraints=constraint).x
                s_t += np.sum(np.abs(b_tminus1 - b_t * k))

            turnover = s_t / (2 * cumulative_time)
            print(L,eta,turnover)
            metrics_df = metrics_df.append({
                '策略': f'eta{eta}_L{L}',
                '换手率': s_t / (2 * cumulative_time)
            }, ignore_index=True)
metrics_df.to_excel(f"改变eta、L的换手率.xlsx", index=False)
'''
metrics_df = pd.read_excel(f"改变eta、L的换手率.xlsx")
results = pd.DataFrame()
# 遍历文件夹中的所有文件
for index,row in metrics_df.iterrows():
    eta, L = row['策略'].lstrip('eta').split('_L') # 从文件名中提取eta和L的值
    # 获取最后一天的累积收益
    results = results.append({'eta': eta, 'L': L, '累积收益': row['换手率']}, ignore_index=True)
results = results.sort_values('L')
heatmap_data = results.pivot('L', 'eta', '累积收益') # 创建一个矩阵来存储热力图的数据

# 创建热力图
fig, ax = plt.subplots(figsize=(10, 4))
sns.heatmap(heatmap_data,  annot=True, fmt=".4f", cmap='YlOrRd', ax=ax, yticklabels=True, cbar_kws={'pad': 0.01})
ax.set_aspect(1)
plt.gca().invert_yaxis()
#plt.title(f'Cumulative Wealth with \u03B7 and L Changed')
plt.xlabel(f'\u03B7')
plt.ylabel('L')

#ax.set_aspect(2)
plt.savefig('改变eta、L的换手率.png',dpi=600)
plt.close()