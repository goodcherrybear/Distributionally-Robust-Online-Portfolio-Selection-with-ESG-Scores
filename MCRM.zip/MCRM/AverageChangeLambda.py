import pandas as pd

# 初始化一个空的DataFrame来存储所有文件的累积收益
all_cumulative_wealth = pd.DataFrame()

for i in range(2):
    # 读取每个文件
    df = pd.read_excel(f'改变轮盘赌lambda的累积收益/cumulative_wealth_lambda_{i}.xlsx')

    # 将累积收益列添加到all_cumulative_wealth
    all_cumulative_wealth = all_cumulative_wealth.append(df['累积收益'], ignore_index=True)

# 计算平均值
average_cumulative_wealth = all_cumulative_wealth.mean()

# 创建一个新的DataFrame来存储日期和平均累积收益
average_df = pd.DataFrame()
average_df['Date'] = df['Date']
average_df['Average Cumulative Wealth'] = average_cumulative_wealth

# 将结果保存到新的xlsx文件中
average_df.to_excel('改变轮盘赌lambda的平均累积收益.xlsx', index=False)
