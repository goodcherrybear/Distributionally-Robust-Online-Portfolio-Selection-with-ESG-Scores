import pandas as pd
import datetime
import numpy as np
from scipy.optimize import minimize

# 读取收益率数据
returns_df = pd.read_excel("returns.xlsx")
returns_df.replace(0, np.nan, inplace=True)
returns_df.bfill(inplace=True)

theta = 0.0005
L_values = [0.01, 0.1, 0.5, 1, 10]
ETA_values = [0, 0.005, 0.01, 0.1, 0.5, 1, 10]
for L in L_values:
    for eta in ETA_values:
        if eta == 0.005 and L == 0.1:
            print('ok')
        else:
            portfolio_allocation = pd.read_excel(f'改变eta、L的投资组合/MyAEC_eta{eta}_L{L}.xlsx')
            if 'index' in portfolio_allocation.columns:
                portfolio_allocation = portfolio_allocation.drop('index', axis=1)
            if 'Unnamed: 0' in portfolio_allocation.columns:
                portfolio_allocation = portfolio_allocation.drop('Unnamed: 0', axis=1)
            portfolio_allocation.columns = [col if isinstance(col, datetime.datetime) or col == 'Stock' else datetime.datetime.strptime(col, '%Y/%m/%d') for col in portfolio_allocation.columns]
            cumulative_time = portfolio_allocation.shape[1]

            cumulative_wealth_df = pd.DataFrame(columns=['Date', '累积收益'])  # 存每天的累积收益
            k_df = pd.DataFrame(columns=['Date', 'k'])  # 存每天的真实资产比例
            S_tminus1 = 1

            cumulative_wealth_df = cumulative_wealth_df.append({'Date': portfolio_allocation.columns[1], '累积收益': S_tminus1},ignore_index=True)

            for t in range(2, cumulative_time):  # 遍历每个交易日
                date = portfolio_allocation.columns[t]  # t时刻的日期
                x_t = returns_df.loc[:, date]  # 所有股票t时刻的相对价格

                b_t = portfolio_allocation.iloc[:, t]  # 所有股票t时刻的分配比例
                b_tminus1 = portfolio_allocation.iloc[:, t - 1]  # 所有股票t-1时刻的分配比例

                # 解交易成本k的目标函数
                def objective_function(k):
                    l1_norm = np.sum(np.abs(b_tminus1 - b_t * k))
                    return 1 - k - theta * l1_norm

                # 定义距离约束
                constraint = (
                {'type': 'ineq', 'fun': lambda k: 1e-20 - np.abs(1 - k - theta * np.sum(np.abs(b_tminus1 - b_t * k)))})
                k = minimize(objective_function, 1, bounds=[(0, 1)], constraints=constraint).x
                s_t = S_tminus1 * k * (np.dot(b_t.T, x_t))  # 考虑成本损失的累计收益
                S_tminus1 = s_t

                print(f"{date}的累积财富为:{s_t[0]}")
                cumulative_wealth_df = cumulative_wealth_df.append({'Date': date, '累积收益': s_t[0]}, ignore_index=True)
            cumulative_wealth_df.to_excel(f"改变eta、L的累积收益/cumulative_wealth_eta{eta}_L{L}.xlsx", index=False)