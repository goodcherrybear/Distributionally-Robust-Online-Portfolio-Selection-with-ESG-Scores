import matplotlib.pyplot as plt
import pandas as pd
import matplotlib.dates as mdates
from matplotlib import rcParams
config = {
            "font.family": 'serif',
            "font.size": 10,# 相当于小四大小
            "mathtext.fontset": 'stix',#matplotlib渲染数学字体时使用的字体，和Times New Roman差别不大
            "font.serif": ['Songti SC'],#宋体
            'axes.unicode_minus': False # 处理负号，即-号
         }
rcParams.update(config)

all_cumulative_wealth = pd.read_excel("所有策略的累积收益.xlsx") # 读取累积收益文件
all_cumulative_wealth['Date'] = pd.to_datetime(all_cumulative_wealth['Date'])
all_cumulative_wealth.set_index('Date', inplace=True)

# 可视化
fig, ax = plt.subplots(figsize=(10, 6))
for column in all_cumulative_wealth.columns:
    ax.plot(all_cumulative_wealth.index, all_cumulative_wealth[column], label=column)
ax.xaxis.set_major_formatter(mdates.DateFormatter('%Y/%m'))
ax.xaxis.set_major_locator(mdates.MonthLocator(bymonth=[2, 8])) # x轴每3个月显示
#ax.set_xticks(all_cumulative_wealth.index)
#ax.set_xticklabels(all_cumulative_wealth.index.strftime('%Y-%m'), rotation=45)
plt.title('Cumulative Wealth of All Strategies')
plt.xlabel('Date')
plt.ylabel('Cumulative Wealth')
plt.legend(loc='upper left',ncol=2)
plt.grid(False)
plt.savefig('所有策略的累积收益.png',dpi=600)
plt.close()