import pandas as pd
import numpy as np
import cvxpy as cp
from CalculateLambdaRoulette import calculate_lambda_RW
from CalculateGammaTenYearRobust import calculate_gamma
import warnings
warnings.filterwarnings("ignore")
import time
import pickle

# 读取历史收益数据
df = pd.read_excel('daily_returns.xlsx')

# 计算每个行业的股票每日均值
df_grouped = df.groupby('industry_gics').mean()

# 获取行业列表和日期列表
industries = df_grouped.index.tolist()
n = len(industries)  # 行业数量（x长度，需要分配的比例数量）
dates = df.columns[4:].tolist()

# 从文件中读取 mu_hat 和 Sigma_hat
with open('mu_hat.pkl', 'rb') as f:
    ten_year_mu_hat = pickle.load(f)
with open('Sigma_hat.pkl', 'rb') as f:
    ten_year_Sigma_hat = pickle.load(f)

# 初始化一个DataFrame来保存每个行业每个月的投资比例
portfolio_allocations = pd.DataFrame(index=industries)
# 初始化一个DataFrame来保存每个月的收益
monthly_returns = pd.DataFrame(index=['all'])
# 初始化一个DataFrame来保存每个月的标准差
monthly_var = pd.DataFrame(index=['all'])
monthly_objective_values = pd.DataFrame(index=['all'])

# 初始化状态转移矩阵为均匀分布
state_transition_matrix = np.ones((11, 11))
# 设置lambda的候选值
lambda_values = [0, 0.1, 0.2, 0.3, 0.4, 0.5, 0.6, 0.7, 0.8, 0.9, 1]
selected_lambdas = []

current_lambda = None
next_lambda = None
current_year_index = 2019
current_month_index = 1
current_index = 0
monthly_data_index = []
while current_index < len(dates)-2:
    start_time = time.time()  # 记录一个月的运行时间
    # 获取一个月的数据
    for date in dates:
        date_str = date.strftime("%Y/%m/%d")
        year = int(date_str.split("/")[0])
        month = int(date_str.split("/")[1].lstrip('0'))
        if year == current_year_index and month == current_month_index:
            monthly_data_index.append(date)
            current_index += 1
        elif year == current_year_index and month > current_month_index:
            current_month_index += 1
            break
        elif year == current_year_index + 1:
            current_year_index += 1
            current_month_index = 1
            break

    monthly_data = df_grouped.loc[:, monthly_data_index[0]:monthly_data_index[-1]]
    current_date = dates[current_index - 1]

    # 均值的经验估计
    mu_hat = monthly_data.mean(axis=1, skipna=True).values

    # 计算协方差的经验估计
    returns_data_centered = monthly_data - mu_hat[:, np.newaxis]
    Sigma_hat = (1 / len(monthly_data_index)) * np.dot(returns_data_centered, returns_data_centered.T)

    gamma1, gamma2 = calculate_gamma(ten_year_mu_hat, ten_year_Sigma_hat, current_date.strftime('%Y/%m'), mu_hat)

    # Mean-CVaR Robust Model
    x = cp.Variable(n)
    alpha = cp.Variable()
    p1 = cp.Variable()
    t = cp.Variable()
    M = cp.Variable((n, n), symmetric=True)
    V = cp.Variable((n, n), symmetric=True)
    v = cp.Variable(n)

    if current_lambda is None:
        current_lambda = np.random.choice(lambda_values)
    else:
        current_lambda = next_lambda
    selected_lambdas.append(current_lambda)
    print(f"lambda:{current_lambda}")

    theta = 0.05  # 假设theta的值,CVaR_theta

    objective = cp.Minimize(current_lambda * alpha + p1 + gamma2 * (cp.trace(M * Sigma_hat)))

    # 将向量和数转换为二维矩阵
    v_2D = v[:, None]
    t_2D = t[None, None]
    constrain_CVaR = cp.vstack([cp.hstack([V,v_2D]),cp.hstack([v_2D.T,t_2D])])
    constrain_CVaR_1 = cp.vstack([cp.hstack([M, ((1/2) * (-2*M * mu_hat - 2*v + (current_lambda / theta - current_lambda + 1) * x))[:, None]]),cp.hstack([((1/2) * (-2*M * mu_hat - 2*v + (current_lambda / theta - current_lambda + 1) * x))[:, None].T,
                                                                                                           (p1 + mu_hat.T * M * mu_hat - cp.trace(Sigma_hat * V) + 2 * v.T * mu_hat - gamma1 * t + current_lambda * alpha / theta)[None,None]])])
    constrain_CVaR_2 = cp.vstack([cp.hstack([M, ((1/2) *(2*M * mu_hat + 2*v + (current_lambda - 1) * x))[:, None]]),cp.hstack([((1/2) *(2*M * mu_hat + 2*v + (current_lambda - 1) * x))[:, None].T,
                                                                                                           (p1 + mu_hat.T * M * mu_hat - cp.trace(Sigma_hat * V) + 2 * v.T * mu_hat - gamma1 * t)[None,None]])])
    constraints = [x >= 0,
                   cp.sum(x) == 1,
                   M >> 0,
                   #Q >> 0,
                   constrain_CVaR >> 0,
                   constrain_CVaR_1 >> 0,
                   constrain_CVaR_2 >> 0,
                   ]

    prob = cp.Problem(objective, constraints)

    # 设置求解器参数
    prob.solve(solver=cp.SCS, max_iters = 5000, verbose=False)

    objective_value = prob.value
    monthly_objective_values.loc['all', current_date.strftime('%Y/%m')] = objective_value

    x_value = x.value
    x_value[x_value < 0] = 0
    # 输出结果
    portfolio_allocations[current_date.strftime('%Y/%m')] = x_value
    # 计算投资组合的收益并保存到DataFrame中
    portfolio_return = np.dot(mu_hat, x_value)
    monthly_returns.loc['all', current_date.strftime('%Y/%m')] = portfolio_return
    portfolio_std = np.sqrt(np.dot(x_value, np.dot(Sigma_hat, x_value)))
    monthly_var.loc['all', current_date.strftime('%Y/%m')] = portfolio_std

    # 轮盘赌计算lambda
    # 计算使得该期夏普率最高的lambda
    best_sharpe_ratio = -np.inf
    for lambda_param in lambda_values:
        # Mean-CVaR Robust Model
        x = cp.Variable(n)
        alpha = cp.Variable()
        p1 = cp.Variable()
        t = cp.Variable()
        M = cp.Variable((n, n), symmetric=True)
        V = cp.Variable((n, n), symmetric=True)
        v = cp.Variable(n)

        theta = 0.05  # 假设theta的值,CVaR_theta

        objective = cp.Minimize(lambda_param * alpha + p1 + gamma2 * (cp.trace(M * Sigma_hat)))

        # 将向量和数转换为二维矩阵
        v_2D = v[:, None]
        t_2D = t[None, None]
        constrain_CVaR = cp.vstack([cp.hstack([V, v_2D]), cp.hstack([v_2D.T, t_2D])])
        constrain_CVaR_1 = cp.vstack(
            [cp.hstack([M, (M * mu_hat + v + (lambda_param / theta + lambda_param - 1) * x)[:, None]]),
             cp.hstack([(M * mu_hat + v + (lambda_param / theta + lambda_param - 1) * x)[:, None].T,
                        (p1 + mu_hat.T * M * mu_hat - cp.trace(
                            Sigma_hat * V) + 2 * v.T * mu_hat - gamma1 * t + lambda_param * alpha / theta)[
                            None, None]])])
        constrain_CVaR_2 = cp.vstack([cp.hstack([M, (M * mu_hat + v + (lambda_param - 1) * x)[:, None]]),
                                      cp.hstack([(M * mu_hat + v + (lambda_param - 1) * x)[:, None].T,
                                                 (p1 + mu_hat.T * M * mu_hat - cp.trace(
                                                     Sigma_hat * V) + 2 * v.T * mu_hat - gamma1 * t)[None, None]])])
        constraints = [x >= 0,
                       cp.sum(x) == 1,
                       M >> 0,
                       constrain_CVaR >> 0,
                       constrain_CVaR_1 >> 0,
                       constrain_CVaR_2 >> 0,
                       ]

        prob = cp.Problem(objective, constraints)
        prob.solve(solver=cp.SCS, max_iters=5000, verbose=False)

        # 夏普比率指标
        x_value = x.value
        x_value[x_value < 0] = 0
        portfolio_return = np.dot(mu_hat, x_value)
        risk_free_rate = 0.0101  # 假设无风险收益率为1.01%
        portfolio_std_dev = np.sqrt(np.dot(x_value, np.dot(Sigma_hat, x_value)))  # 计算投资组合的标准差
        sharpe_ratio = (portfolio_return - risk_free_rate) / portfolio_std_dev  # 计算夏普比率
        print(f"lambda为:{lambda_param}时的最优投资组合为{x_value},收益为{portfolio_return},标准差为{portfolio_return},夏普率为{sharpe_ratio}")
        if sharpe_ratio > best_sharpe_ratio:
            best_lambda = lambda_param
            best_sharpe_ratio = sharpe_ratio
            best_portfolio = x_value
    print(f"{current_date.strftime('%Y/%m')}的最优lambda为{best_lambda}")

    state_index = int(current_lambda * 10)  # 上一个月的lambda索引
    best_state_index = int(best_lambda * 10)  # 当前月最优的lambda索引

    state_transition_matrix[state_index, best_state_index] += 1  # 更新状态转移矩阵
    print(f"此时的转移矩阵为{state_transition_matrix}")
    state_transition_matrix_probabilities = state_transition_matrix / state_transition_matrix.sum(axis=1,keepdims=True)  # 将状态转移的频率转换为概率
    transition_probabilities = state_transition_matrix_probabilities[state_index]  # 获取当前状态对应的转移概率

    next_lambda = np.random.choice(range(11), p=transition_probabilities) / 10.0  # 根据转移概率预测下一个状态的索引，并换回状态
    # 轮盘赌计算lambda完成

    print(f"{current_date.strftime('%Y/%m')}的投资组合为：{x_value}，收益率为：{portfolio_return}")
    end_time = time.time()  # 记录一个月的运行时间
    print(f"{current_date.strftime('%Y/%m')}的模型求解完成，计算时间为{end_time - start_time}秒")

    monthly_data_index = [] # 清空monthly_data_index

# 将DataFrame保存到xlsx文件中
portfolio_allocations.to_excel('轮盘赌+动态gamma/SCS/动态状态转移矩阵0-1/行业最优投资组合（NewMCRM）.xlsx')
monthly_returns.to_excel('轮盘赌+动态gamma/SCS/动态状态转移矩阵0-1/最优投资组合的收益（NewMCRM）.xlsx')
monthly_var.to_excel('轮盘赌+动态gamma/SCS/动态状态转移矩阵0-1/最优投资组合的标准差（NewMCRM）.xlsx')
monthly_objective_values.to_excel('轮盘赌+动态gamma/SCS/动态状态转移矩阵0-1/目标函数值（NewMCRM）.xlsx')
with open('轮盘赌+动态gamma/SCS/动态状态转移矩阵0-1/lambda_values.txt', 'w') as f:
    for item in selected_lambdas:
        f.write("%s\n" % item)