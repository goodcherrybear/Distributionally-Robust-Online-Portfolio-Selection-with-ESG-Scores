import numpy as np
import pandas as pd
import cvxpy as cp
import time

def other_model():
    # 读取历史收益数据
    df = pd.read_excel('daily_returns.xlsx')

    # 计算每个行业的股票每日均值
    df_grouped = df.groupby('industry_gics').mean()

    # 获取行业列表和日期列表
    industries = df_grouped.index.tolist()
    n = len(industries)  # 行业数量（x长度，需要分配的比例数量）
    dates = df.columns[4:].tolist()

    # 初始化一个DataFrame来保存每个行业每个月的投资比例
    portfolio_allocations_mv = pd.DataFrame(index=industries)
    portfolio_allocations_ew = pd.DataFrame(index=industries)
    # 初始化一个DataFrame来保存每个月的收益
    monthly_returns_mv = pd.DataFrame(index=['all'])
    monthly_returns_ew = pd.DataFrame(index=['all'])
    # 初始化一个DataFrame来保存每个月的标准差
    monthly_var_mv = pd.DataFrame(index=['all'])
    monthly_var_ew = pd.DataFrame(index=['all'])

    current_year_index = 2019
    current_month_index = 2
    current_index = 21
    monthly_data_index = []
    while current_index < len(dates)-2:
        start_time = time.time()  # 记录一个月的运行时间
        # 获取一个月的数据
        for date in dates:
            date_str = date.strftime("%Y/%m/%d")
            year = int(date_str.split("/")[0])
            month = int(date_str.split("/")[1].lstrip('0'))
            if year == current_year_index and month == current_month_index:
                monthly_data_index.append(date)
                current_index += 1
            elif year == current_year_index and month > current_month_index:
                current_month_index += 1
                break
            elif year == current_year_index + 1:
                current_year_index += 1
                current_month_index = 1
                break

        monthly_data = df_grouped.loc[:, monthly_data_index[0]:monthly_data_index[-1]]
        current_date = dates[current_index - 1]

        # 当月的平均收益
        mu_hat = monthly_data.mean(axis=1, skipna=True).values

        # 当月的协方差
        returns_data_centered = monthly_data - mu_hat[:, np.newaxis]
        Sigma_hat = np.dot(returns_data_centered, returns_data_centered.T)

        # 均值-方差模型
        x = cp.Variable(n)
        objective = cp.Minimize(cp.quad_form(x, Sigma_hat))
        constraints = [cp.sum(x) == 1, x >= 0]
        prob = cp.Problem(objective, constraints)
        prob.solve()

        # 输出结果
        x_value = x.value
        x_value[x_value < 0] = 0
        portfolio_allocations_mv[current_date.strftime('%Y/%m')] = x.value

        # 计算投资组合的收益并保存到DataFrame中
        portfolio_return = np.dot(mu_hat, x_value) # 当月所有行业加权收益（值）
        portfolio_std = np.sqrt(np.dot(x_value, np.dot(Sigma_hat, x_value))) # 当月所有行业方差（值）
        monthly_returns_mv.loc['all', current_date.strftime('%Y/%m')] = portfolio_return
        monthly_var_mv.loc['all', current_date.strftime('%Y/%m')] = portfolio_std

        # 等权重投资组合
        portfolio_allocations_ew[current_date.strftime('%Y/%m')] = np.ones(n) / n
        monthly_returns_ew.loc[:, current_date.strftime('%Y/%m')] = np.dot((np.ones(n) / n), mu_hat)
        monthly_var_ew.loc[:, current_date.strftime('%Y/%m')] = np.sqrt(np.dot((np.ones(n) / n), np.dot(Sigma_hat, (np.ones(n) / n))))

    # 保存到Excel文件
    portfolio_allocations_mv.to_excel('行业最优投资组合（mv）.xlsx')
    portfolio_allocations_ew.to_excel('行业最优投资组合（ew）.xlsx')
    monthly_returns_mv.to_excel('最优投资组合的收益（mv）.xlsx')
    monthly_returns_ew.to_excel('最优投资组合的收益（ew）.xlsx')
    monthly_var_mv.to_excel('最优投资组合的标准差（mv）.xlsx')
    monthly_var_ew.to_excel('最优投资组合的标准差（ew）.xlsx')


# 计算性能指标
def calculate_performance(portfolio_returns, portfolio_stds, rf):
    portfolio_return = portfolio_returns.mean(axis=1)
    portfolio_std = portfolio_stds.mean(axis=1)
    # 计算夏普比率
    #sharpe_ratio = (portfolio_return - rf) / portfolio_std
    '''
    # 计算索提诺比率
    negative_returns = portfolio_returns[portfolio_return < 0]
    negative_std = negative_returns.std()
    sortino_ratio = (portfolio_return - rf) / negative_std

    # 计算最大回撤
    #print(portfolio_returns)
    cumulative_returns = (1 + portfolio_returns).cumprod()
    max_drawdown = np.max(np.maximum.accumulate(cumulative_returns) - cumulative_returns)
    '''
    return float(portfolio_return[0]), float(portfolio_std[0])

def compare_model():
    monthly_returns_MCRM = pd.read_excel('轮盘赌+动态gamma/SCS/动态状态转移矩阵0-1/最优投资组合的收益（NewMCRM）.xlsx')
    monthly_var_MCRM = pd.read_excel('轮盘赌+动态gamma/SCS/动态状态转移矩阵0-1/最优投资组合的标准差（NewMCRM）.xlsx')
    monthly_returns_MCRM.rename(columns={'Unnamed: 0': 'all'}, inplace=True)
    monthly_var_MCRM.rename(columns={'Unnamed: 0': 'all'}, inplace=True)
    monthly_returns_MCRM.set_index('all', inplace=True)
    monthly_var_MCRM.set_index('all', inplace=True)

    monthly_returns_old_MCRM = pd.read_excel('/Users/yinmengzi/Desktop/行业投资比例/轮盘赌+动态gamma/SCS/动态状态转移矩阵0-1/最优投资组合的收益（MCRM）.xlsx')
    monthly_var_old_MCRM = pd.read_excel('/Users/yinmengzi/Desktop/行业投资比例/轮盘赌+动态gamma/SCS/动态状态转移矩阵0-1/最优投资组合的标准差（MCRM）.xlsx')
    monthly_returns_old_MCRM.rename(columns={'Unnamed: 0': 'all'}, inplace=True)
    monthly_var_old_MCRM.rename(columns={'Unnamed: 0': 'all'}, inplace=True)
    monthly_returns_old_MCRM.set_index('all', inplace=True)
    monthly_var_old_MCRM.set_index('all', inplace=True)

    monthly_returns_mv = pd.read_excel('最优投资组合的收益（mv）.xlsx')
    monthly_var_mv = pd.read_excel('最优投资组合的标准差（mv）.xlsx')
    monthly_returns_mv.set_index('all', inplace=True)
    monthly_var_mv.set_index('all', inplace=True)

    monthly_returns_ew = pd.read_excel('最优投资组合的收益（ew）.xlsx')
    monthly_var_ew = pd.read_excel('最优投资组合的标准差（ew）.xlsx')
    monthly_returns_ew.set_index('all', inplace=True)
    monthly_var_ew.set_index('all', inplace=True)

    rf = 0.0101 # 假设无风险收益率为1.01%

    performance_mv = calculate_performance(monthly_returns_mv, monthly_var_mv, rf) # 计算均值-方差模型的性能指标
    performance_ew = calculate_performance(monthly_returns_ew, monthly_var_ew, rf) # 计算等权重投资组合的性能指标
    performance_MCRM = calculate_performance(monthly_returns_MCRM, monthly_var_MCRM, rf) # 计算MCRM模型投资组合的性能指标
    performance_old_MCRM = calculate_performance(monthly_returns_old_MCRM, monthly_var_old_MCRM, rf)  # 计算MCRM模型投资组合的性能指标
    obj_MCRM_df = pd.read_excel('轮盘赌+动态gamma/SCS/动态状态转移矩阵0-1/目标函数值（NewMCRM）.xlsx')
    obj_MCRM_df.rename(columns={'Unnamed: 0': 'all'}, inplace=True)
    obj_MCRM_df.set_index('all', inplace=True)
    obj_MCRM = obj_MCRM_df.mean(axis=1)
    obj_old_MCRM_df = pd.read_excel('/Users/yinmengzi/Desktop/行业投资比例/轮盘赌+动态gamma/SCS/动态状态转移矩阵0-1/目标函数值（MCRM）.xlsx')
    obj_old_MCRM_df.rename(columns={'Unnamed: 0': 'all'}, inplace=True)
    obj_old_MCRM_df.set_index('all', inplace=True)
    obj_old_MCRM = obj_old_MCRM_df.mean(axis=1)

    # 保存性能指标到Excel文件
    performance_df = pd.DataFrame(index=['Return', 'Std','Object'])
    performance_df['M-V'] = list(performance_mv)+['']
    performance_df['EW'] = list(performance_ew)+['']
    performance_df['MCRM'] = list(performance_old_MCRM)+[float(obj_old_MCRM)]
    performance_df['New MCRM'] = list(performance_MCRM)+[float(obj_MCRM)]

    performance_df.transpose().to_excel('轮盘赌+动态gamma/SCS/动态状态转移矩阵0-1/模型性能比较.xlsx')
#other_model()
compare_model()

