import pandas as pd
import numpy as np
import cvxpy as cp
from datetime import datetime, timedelta
import warnings
from CalculateGammaTenYearRobust import calculate_five_year_gamma
warnings.filterwarnings("ignore")
import time
import pickle

df = pd.read_excel('/Users/yinmengzi/Desktop/行业投资比例/ten_year_daily_returns.xlsx')  # 读取历史收益数据
df_grouped = df.groupby('industry_gics').mean()  # 计算每个行业的股票每日均值
# 获取行业列表和日期列表
industries = df_grouped.index.tolist()
n = len(industries)  # 行业数量（x长度，需要分配的比例数量）
dates = df.columns[4:].tolist()

# 计算lambda
def calculate_lambda_RW(state_transition_matrix, current_lambda):
    state_index = int(current_lambda * 10) - 1  # 将当前状态转换为索引
    transition_probabilities = state_transition_matrix[state_index]  # 获取当前状态对应的转移概率
    next_state_index = np.random.choice(range(10), p=transition_probabilities)  # 根据转移概率预测下一个状态的索引
    next_state = next_state_index / 10.0  # 将索引转换回状态
    return next_state

# 计算状态转移矩阵
def calculate_state_transition_matrix(best_lambdas):
    state_transition_matrix = np.zeros((10, 10))  # 初始化状态转移矩阵

    # 遍历最优状态列表，统计状态转移的频率
    for i in range(1, len(best_lambdas)):
        # 获取状态i和状态j
        state_i = int(best_lambdas[i - 1] * 10) - 1
        state_j = int(best_lambdas[i] * 10) - 1

        # 更新状态转移矩阵
        state_transition_matrix[state_i][state_j] += 1

    # 检查是否有某些状态没有转移到其他状态，如果有，添加一个小的正数
    row_sums = state_transition_matrix.sum(axis=1)
    rows_without_transition = np.where(row_sums == 0)[0]
    if len(rows_without_transition) > 0:
        state_transition_matrix[rows_without_transition, :] += 1e-10

    state_transition_matrix = state_transition_matrix / state_transition_matrix.sum(axis=1,keepdims=True)  # 将状态转移的频率转换为概率

    np.save('轮盘赌+动态gamma/state_transition_matrix.npy', state_transition_matrix)  # 保存到文件中
    print(state_transition_matrix)
    return state_transition_matrix

# 计算2014-1018五年间每个月最合适的lambda_param
def calculate_best_lambda():
    # 从文件中读取前五年的mu_hat和Sigma_hat
    with open('five_year_mu_hat.pkl', 'rb') as f:
        five_year_mu_hat = pickle.load(f)
    with open('five_year_Sigma_hat.pkl', 'rb') as f:
        five_year_Sigma_hat = pickle.load(f)

    current_year_index = 2014
    current_month_index = 1
    current_index = 3620
    monthly_data_index = []

    best_lambdas = []  # 记录每个月的最优lambda

    while current_index < len(dates):
        start_time = time.time()  # 记录一个月的运行时间
        # 初始化最优的lambda参数和最大的目标函数值
        best_lambda = None
        min_objective = np.inf
        best_sharpe_ratio = -np.inf
        best_portfolio = None
        # 获取一个月的数据
        for date in dates:
            date_str = date.strftime("%Y/%m/%d")
            year = int(date_str.split("/")[0])
            month = int(date_str.split("/")[1].lstrip('0'))

            if year == current_year_index and month == current_month_index:
                monthly_data_index.append(date)
                current_index += 1
            elif year == current_year_index and month > current_month_index:
                current_month_index += 1
                break
            elif year == current_year_index + 1:
                current_year_index += 1
                current_month_index = 1
                break

        monthly_data = df_grouped.loc[:, monthly_data_index[0]:monthly_data_index[-1]]
        #print(monthly_data)
        # 均值的经验估计
        mu_hat = monthly_data.mean(axis=1, skipna=True).values
        #print(mu_hat)
        # 计算协方差的经验估计
        returns_data_centered = monthly_data - mu_hat[:, np.newaxis]
        Sigma_hat = (1 / len(monthly_data_index)) * np.dot(returns_data_centered, returns_data_centered.T)

        current_date = dates[current_index - 1]
        gamma1, gamma2 = calculate_five_year_gamma(five_year_mu_hat, five_year_Sigma_hat, current_date.strftime('%Y/%m'), mu_hat)

        for lambda_param in np.linspace(0.1, 0.5, 5):
            # Mean-CVaR Robust Model
            x = cp.Variable(n)
            alpha = cp.Variable()
            p1 = cp.Variable()
            t = cp.Variable()
            # q1 = cp.Variable()
            # g = cp.Variable()
            M = cp.Variable((n, n), symmetric=True)
            V = cp.Variable((n, n), symmetric=True)
            # Q = cp.Variable((n, n), symmetric=True)
            # U = cp.Variable((n, n), symmetric=True)
            v = cp.Variable(n)
            # h = cp.Variable(n)

            theta = 0.05  # 假设theta的值,CVaR_theta

            objective = cp.Minimize(lambda_param * alpha + p1 + gamma2 * (cp.trace(M * Sigma_hat)))

            # 将向量和数转换为二维矩阵
            v_2D = v[:, None]
            t_2D = t[None, None]
            constrain_CVaR = cp.vstack([cp.hstack([V, v_2D]), cp.hstack([v_2D.T, t_2D])])
            # constrain_CReturn = cp.vstack([cp.hstack([U,h_2D]),cp.hstack([h_2D.T,g_2D])])
            constrain_CVaR_1 = cp.vstack(
                [cp.hstack([M, (M * mu_hat + v + (lambda_param / theta + lambda_param - 1) * x)[:, None]]),
                 cp.hstack([(M * mu_hat + v + (lambda_param / theta + lambda_param - 1) * x)[:, None].T,
                            (p1 + mu_hat.T * M * mu_hat - cp.trace(
                                Sigma_hat * V) + 2 * v.T * mu_hat - gamma1 * t + lambda_param * alpha / theta)[
                                None, None]])])
            constrain_CVaR_2 = cp.vstack([cp.hstack([M, (M * mu_hat + v + (lambda_param - 1) * x)[:, None]]),
                                          cp.hstack([(M * mu_hat + v + (lambda_param - 1) * x)[:, None].T,
                                                     (p1 + mu_hat.T * M * mu_hat - cp.trace(
                                                         Sigma_hat * V) + 2 * v.T * mu_hat - gamma1 * t)[None, None]])])
            # constrain_CReturn_1 = cp.vstack([cp.hstack([Q, ((1 / 2) * (x - 2 * Q * mu_hat - 2 * h))[:, None]]),cp.hstack([((1 / 2) * (x - 2 * Q * mu_hat - 2 * h))[:, None].T,
            #                                                                                                       (q1 + mu_hat.T * Q * mu_hat - cp.trace(Sigma_hat * V) + 2 * mu_hat.T * h - gamma1 * g)[None,None]])])
            constraints = [x >= 0,
                           cp.sum(x) == 1,
                           M >> 0,
                           # Q >> 0,
                           constrain_CVaR >> 0,
                           # constrain_CReturn >> 0,
                           constrain_CVaR_1 >> 0,
                           constrain_CVaR_2 >> 0,
                           # constrain_CReturn_1 >> 0
                           ]

            prob = cp.Problem(objective, constraints)
            # 设置求解器参数
            prob.solve(solver=cp.SCS, max_iters=5000, verbose=False)

            # 夏普比率指标
            x_value = x.value
            x_value[x_value < 0] = 0
            portfolio_return = np.sum((1 + mu_hat) * x_value)
            risk_free_rate = 0.0101  # 假设无风险收益率为1.01%
            portfolio_std_dev = np.std((1 + mu_hat) * x_value)  # 计算投资组合的标准差
            sharpe_ratio = (portfolio_return - risk_free_rate) / portfolio_std_dev  # 计算夏普比率
            print(f"夏普率:{sharpe_ratio}")
            if sharpe_ratio > best_sharpe_ratio:
                best_lambda = lambda_param
                best_sharpe_ratio = sharpe_ratio
                best_portfolio = x_value

        best_lambdas.append(best_lambda)
        end_time = time.time()  # 记录一个月的运行时间
        print(f"{current_date.strftime('%Y/%m')}的最优lambda为{best_lambda}，最大夏普率为{best_sharpe_ratio}，投资组合为：{best_portfolio}")
        print(f"{current_date.strftime('%Y/%m')}的计算时间为{end_time - start_time}秒")
        monthly_data_index = []  # 清空monthly_data_index

    with open('轮盘赌+动态gamma/best_lambdas_sharp.txt', 'w') as f:
        # 遍历列表的每个元素
        for item in best_lambdas:
            # 将每个元素写入文件，并在末尾添加换行符
            f.write(str(item) + '\n')

    return best_lambdas

calculate_best_lambda()
best_lambdas_file = open("轮盘赌+动态gamma/best_lambdas_sharp.txt")
best_lambdas = [float(line.strip('\n')) for line in best_lambdas_file.readlines()]
print(best_lambdas)

calculate_state_transition_matrix(best_lambdas)
state_transition_matrix = np.load("state_transition_matrix.npy")
print(state_transition_matrix)
