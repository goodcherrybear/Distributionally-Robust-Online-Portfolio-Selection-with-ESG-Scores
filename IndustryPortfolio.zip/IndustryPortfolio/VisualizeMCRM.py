import matplotlib.pyplot as plt
import pandas as pd
from matplotlib import rcParams
config = {
            "font.family": 'serif',
            "font.size": 12,# 相当于小四大小
            "mathtext.fontset": 'stix',#matplotlib渲染数学字体时使用的字体，和Times New Roman差别不大
            "font.serif": ['Songti SC'],#宋体
            'axes.unicode_minus': False # 处理负号，即-号
         }
rcParams.update(config)

# 改进MCRM模型结果可视化
def Visualize_IMCRM_portfolio():
    # 读取数据
    portfolio_allocations = pd.read_excel('轮盘赌+动态gamma/SCS/动态状态转移矩阵0-1/行业最优投资组合（NewMCRM）.xlsx', index_col=0)

    # 创建一个新的figure
    fig, ax = plt.subplots(figsize=(18, 6))

    # 使用stackplot函数创建堆叠图
    plt.stackplot(portfolio_allocations.columns, portfolio_allocations.values, labels=portfolio_allocations.index, alpha=1)
    ax.set_xlim([0,max(portfolio_allocations.columns)])
    ax.set_ylim([0,1])
    # 添加图例和标题
    plt.legend(loc='upper left',bbox_to_anchor=(1, 1))
    plt.title('Stage 1: Optimal industry portfolios (Integrated MCRM)')
    plt.xticks(rotation=45)

    # 显示图形
    #plt.show()
    plt.savefig('轮盘赌+动态gamma/SCS/动态状态转移矩阵0-1/第一阶段行业最优投资组合（改进MCRM）', bbox_inches='tight')
    plt.close()

# 原始MCRM模型结果可视化
def Visualize_SMCRM_portfolio():
    # 读取数据
    portfolio_allocations = pd.read_excel('/Users/yinmengzi/Desktop/行业投资比例/轮盘赌+动态gamma/SCS/动态状态转移矩阵0-1/行业最优投资组合（MCRM）.xlsx', index_col=0)

    # 创建一个新的figure
    fig, ax = plt.subplots(figsize=(18, 6))

    # 使用stackplot函数创建堆叠图
    plt.stackplot(portfolio_allocations.columns, portfolio_allocations.values, labels=portfolio_allocations.index,
                  alpha=1)
    ax.set_xlim([0, max(portfolio_allocations.columns)])
    ax.set_ylim([0, 1])
    # 添加图例和标题
    plt.legend(loc='upper left', bbox_to_anchor=(1, 1))
    plt.title('Stage 1: Optimal industry portfolios (Sequential MCRM)')
    plt.xticks(rotation=45)

    # 显示图形
    # plt.show()
    plt.savefig('轮盘赌+动态gamma/SCS/动态状态转移矩阵0-1/第一阶段行业最优投资组合（原始MCRM）', bbox_inches='tight')
    plt.close()

Visualize_IMCRM_portfolio()
#Visualize_SMCRM_portfolio()
