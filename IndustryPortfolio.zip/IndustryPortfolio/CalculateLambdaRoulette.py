import numpy as np
import warnings
warnings.filterwarnings("ignore")

def calculate_lambda_RW(state_transition_matrix, current_lambda):
    state_index = int(current_lambda * 10) - 1
    transition_probabilities = state_transition_matrix[state_index]

    # 使用轮盘赌算法选择下一个状态的索引
    cumulative_probabilities = np.cumsum(transition_probabilities)
    random_number = np.random.rand()  # 生成一个0到1之间的随机数
    next_state_index = np.searchsorted(cumulative_probabilities, random_number)

    # 将索引转换为状态
    next_state = next_state_index / 10.0
    return next_state
