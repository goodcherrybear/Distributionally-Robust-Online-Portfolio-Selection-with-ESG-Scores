import pandas as pd
import numpy as np
import cvxpy as cp
from CalculateLambdaRoulette import calculate_lambda_RW
import warnings
warnings.filterwarnings("ignore")
import time
import pickle
import os

# 读取历史收益数据
df = pd.read_excel('daily_returns.xlsx')

# 计算每个行业的股票每日均值
df_grouped = df.groupby('industry_gics').mean()

# 获取行业列表和日期列表
industries = df_grouped.index.tolist()
n = len(industries)  # 行业数量（x长度，需要分配的比例数量）
dates = df.columns[4:].tolist()

# 从文件中读取 mu_hat 和 Sigma_hat
with open('mu_hat.pkl', 'rb') as f:
    ten_year_mu_hat = pickle.load(f)
with open('Sigma_hat.pkl', 'rb') as f:
    ten_year_Sigma_hat = pickle.load(f)

gamma_df = pd.read_excel('轮盘赌+动态gamma/SCS/gamma_values.xlsx').set_index('date')

# 初始化一个DataFrame来保存每个行业每个月的结果
portfolio_allocations = pd.DataFrame(index=industries)
monthly_returns = pd.DataFrame(index=['all'])
monthly_var = pd.DataFrame(index=['all'])
monthly_objective_values = pd.DataFrame(index=['all'])

# 获取前十年lambda的转移矩阵
state_transition_matrix = np.load("轮盘赌+动态gamma/state_transition_matrix.npy")
best_lambdas_file = open("轮盘赌+动态gamma/best_lambdas_sharp.txt")
best_lambdas = [float(line.strip('\n')) for line in best_lambdas_file.readlines()]


def stable_lambda(count):
    last_lambda = best_lambdas[-1]
    current_year_index = 2019
    current_month_index = 2
    current_index = 22
    monthly_data_index = []
    while current_index < len(dates)-2:
        start_time = time.time()  # 记录一个月的运行时间
        # 获取一个月的数据
        for date in dates:
            date_str = date.strftime("%Y/%m/%d")
            year = int(date_str.split("/")[0])
            month = int(date_str.split("/")[1].lstrip('0'))
            if year == current_year_index and month == current_month_index:
                monthly_data_index.append(date)
                current_index += 1
            elif year == current_year_index and month > current_month_index:
                current_month_index += 1
                break
            elif year == current_year_index + 1:
                current_year_index += 1
                current_month_index = 1
                break

        monthly_data = df_grouped.loc[:, monthly_data_index[0]:monthly_data_index[-1]]
        current_date = dates[current_index - 1]

        # 将结果追加入文件
        df_new = pd.DataFrame(
            {'date': [current_date.strftime('%Y/%m')], 'lambda': [last_lambda]})  # 创建一个新的 DataFrame 来存储当前的 gamma 值
        df_new.set_index('date', inplace=True)
        # 如果文件已经存在，读取文件并将新的DataFrame添加到旧的DataFrame中
        if os.path.exists(f'/Users/yinmengzi/Desktop/行业投资比例改进/轮盘赌+动态gamma/SCS/测试轮盘赌/{count}.lambda_values.xlsx'):
            #print('已添加')
            df_old = pd.read_excel(f'/Users/yinmengzi/Desktop/行业投资比例改进/轮盘赌+动态gamma/SCS/测试轮盘赌/{count}.lambda_values.xlsx', index_col='date')
            df = pd.concat([df_old, df_new])
        else:
            df = df_new
        #print(df)
        df.to_excel(f'/Users/yinmengzi/Desktop/行业投资比例改进/轮盘赌+动态gamma/SCS/测试轮盘赌/{count}.lambda_values.xlsx')
        # 均值的经验估计
        mu_hat = monthly_data.mean(axis=1, skipna=True).values

        # 计算协方差的经验估计
        returns_data_centered = monthly_data - mu_hat[:, np.newaxis]
        Sigma_hat = (1 / len(monthly_data_index)) * np.dot(returns_data_centered, returns_data_centered.T)

        # Mean-CVaR Robust Model
        x = cp.Variable(n)
        alpha = cp.Variable()
        p1 = cp.Variable()
        t = cp.Variable()
        q1 = cp.Variable()
        g = cp.Variable()
        M = cp.Variable((n, n), symmetric=True)
        V = cp.Variable((n, n), symmetric=True)
        Q = cp.Variable((n, n), symmetric=True)
        U = cp.Variable((n, n), symmetric=True)
        v = cp.Variable(n)
        h = cp.Variable(n)

        #lambda_param = calculate_lambda(state_transition_matrix, last_lambda)  # 使用马尔可夫链计算lambda参数
        lambda_param = calculate_lambda_RW(state_transition_matrix, last_lambda) # 使用轮盘赌计算lambda参数
        last_lambda = lambda_param # 更新当前lambda值
        theta = 0.05  # 假设theta的值,CVaR_theta

        gamma1 = gamma_df['gamma1'].loc[current_date.strftime('%Y/%m')]
        gamma2 = gamma_df['gamma2'].loc[current_date.strftime('%Y/%m')]

        objective = cp.Minimize((1 - lambda_param) * (q1 + gamma2 * (cp.trace(Q * Sigma_hat))) +
                            lambda_param * (alpha + (gamma2 / theta) * (cp.trace(M * Sigma_hat)) + p1 / theta))

        # 将向量和数转换为二维矩阵
        v_2D = v[:, None]
        h_2D = h[:, None]
        g_2D = g[None, None]
        t_2D = t[None, None]
        constrain_CVaR = cp.vstack([cp.hstack([V,v_2D]),cp.hstack([v_2D.T,t_2D])])
        constrain_CReturn = cp.vstack([cp.hstack([U,h_2D]),cp.hstack([h_2D.T,g_2D])])
        constrain_CVaR_1 = cp.vstack([cp.hstack([M, ((1 / 2) * (-2 * M * mu_hat - 2 * v))[:, None]]),cp.hstack([((1 / 2) * (-2 * M * mu_hat - 2 * v))[:, None].T,
                                                                                                               (p1 + mu_hat.T * M * mu_hat - cp.trace(Sigma_hat * V) + 2 * v.T * mu_hat - gamma1 * t)[None,None]])])
        constrain_CVaR_2 = cp.vstack([cp.hstack([M, ((1 / 2) * (x -2 * M * mu_hat - 2 * v))[:, None]]),cp.hstack([((1 / 2) * (x -2 * M * mu_hat - 2 * v))[:, None].T,
                                                                                                               (alpha + p1 + mu_hat.T * M * mu_hat - cp.trace(Sigma_hat * V) + 2 * v.T * mu_hat - gamma1 * t)[None,None]])])
        constrain_CReturn_1 = cp.vstack([cp.hstack([Q, ((1 / 2) * (x - 2 * Q * mu_hat - 2 * h))[:, None]]),cp.hstack([((1 / 2) * (x - 2 * Q * mu_hat - 2 * h))[:, None].T,
                                                                                                               (q1 + mu_hat.T * Q * mu_hat - cp.trace(Sigma_hat * V) + 2 * mu_hat.T * h - gamma1 * g)[None,None]])])
        constraints = [x >= 0,
                       cp.sum(x) == 1,
                       M >> 0,
                       Q >> 0,
                       constrain_CVaR >> 0,
                       constrain_CReturn >> 0,
                       constrain_CVaR_1 >> 0,
                       constrain_CVaR_2 >> 0,
                       constrain_CReturn_1 >> 0
                       ]

        prob = cp.Problem(objective, constraints)
        #print(f"开始求解{current_year_index}年{current_month_index}月")
        # 设置求解器参数
        prob.solve(solver=cp.SCS, max_iters=5000, verbose=False)
        #prob.solve(solver=cp.SCS, verbose=True)

        x_value = x.value
        x_value[x_value < 0] = 0
        # 输出结果
        portfolio_allocations[current_date.strftime('%Y/%m')] = x_value
        # 计算投资组合的收益并保存到DataFrame中
        portfolio_return = np.dot(mu_hat, x_value)
        monthly_returns.loc['all', current_date.strftime('%Y/%m')] = portfolio_return
        portfolio_std = np.sqrt(np.dot(x_value, np.dot(Sigma_hat, x_value)))
        monthly_var.loc['all', current_date.strftime('%Y/%m')] = portfolio_std
        objective_value = prob.value
        monthly_objective_values.loc['all', current_date.strftime('%Y/%m')] = objective_value

        print(f"{current_date.strftime('%Y/%m')}的投资组合为：{x_value}，收益率为：{portfolio_return}")
        end_time = time.time()  # 记录一个月的运行时间
        print(f"{current_date.strftime('%Y/%m')}的模型求解完成，计算时间为{end_time - start_time}秒")

        monthly_data_index = [] # 清空monthly_data_index

    # 将DataFrame保存到xlsx文件中
    portfolio_allocations.to_excel(f'轮盘赌+动态gamma/SCS/测试轮盘赌/{count}.行业最优投资组合（NewMCRM）.xlsx')
    monthly_returns.to_excel(f'轮盘赌+动态gamma/SCS/测试轮盘赌/{count}.最优投资组合的收益（NewMCRM）.xlsx')
    monthly_var.to_excel(f'轮盘赌+动态gamma/SCS/测试轮盘赌/{count}.最优投资组合的标准差（NewMCRM）.xlsx')
    monthly_objective_values.to_excel(f'轮盘赌+动态gamma/SCS/测试轮盘赌/{count}.目标函数值（NewMCRM）.xlsx')

for count in range(0,30):
    stable_lambda(count)
    print(f"{'='*20}第{count}次测试完成{'='*20}")