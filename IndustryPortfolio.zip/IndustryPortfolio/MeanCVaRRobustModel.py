import pandas as pd
import numpy as np
import cvxpy as cp
from CalculateLambdaRoulette import calculate_lambda_RW
from CalculateGammaTenYearRobust import calculate_gamma
import warnings
warnings.filterwarnings("ignore")
import time
import pickle

# 读取历史收益数据
df = pd.read_excel('daily_returns.xlsx')

# 计算每个行业的股票每日均值
df_grouped = df.groupby('industry_gics').mean()

# 获取行业列表和日期列表
industries = df_grouped.index.tolist()
n = len(industries)  # 行业数量（x长度，需要分配的比例数量）
dates = df.columns[4:].tolist()

# 从文件中读取 mu_hat 和 Sigma_hat
with open('mu_hat.pkl', 'rb') as f:
    ten_year_mu_hat = pickle.load(f)
with open('Sigma_hat.pkl', 'rb') as f:
    ten_year_Sigma_hat = pickle.load(f)

# 初始化一个DataFrame来保存每个行业每个月的投资比例
portfolio_allocations = pd.DataFrame(index=industries)
# 初始化一个DataFrame来保存每个月的收益
monthly_returns = pd.DataFrame(index=['all'])
# 初始化一个DataFrame来保存每个月的标准差
monthly_var = pd.DataFrame(index=['all'])
monthly_objective_values = pd.DataFrame(index=['all'])

# 获取前十年lambda的转移矩阵
state_transition_matrix = np.load("轮盘赌+动态gamma/state_transition_matrix.npy")
best_lambdas_file = open("轮盘赌+动态gamma/best_lambdas_sharp.txt")
best_lambdas = [float(line.strip('\n')) for line in best_lambdas_file.readlines()]
last_lambda = best_lambdas[-1]
#lambda_param = 0.002

current_year_index = 2019
current_month_index = 1
current_index = 0
monthly_data_index = []
while current_index < len(dates)-2:
    start_time = time.time()  # 记录一个月的运行时间
    # 获取一个月的数据
    for date in dates:
        date_str = date.strftime("%Y/%m/%d")
        year = int(date_str.split("/")[0])
        month = int(date_str.split("/")[1].lstrip('0'))
        if year == current_year_index and month == current_month_index:
            monthly_data_index.append(date)
            current_index += 1
        elif year == current_year_index and month > current_month_index:
            current_month_index += 1
            break
        elif year == current_year_index + 1:
            current_year_index += 1
            current_month_index = 1
            break

    monthly_data = df_grouped.loc[:, monthly_data_index[0]:monthly_data_index[-1]]
    current_date = dates[current_index - 1]

    # 均值的经验估计
    mu_hat = monthly_data.mean(axis=1, skipna=True).values

    # 计算协方差的经验估计
    returns_data_centered = monthly_data - mu_hat[:, np.newaxis]
    Sigma_hat = (1 / len(monthly_data_index)) * np.dot(returns_data_centered, returns_data_centered.T)

    # Mean-CVaR Robust Model
    x = cp.Variable(n)
    alpha = cp.Variable()
    p1 = cp.Variable()
    t = cp.Variable()
    #q1 = cp.Variable()
    #g = cp.Variable()
    M = cp.Variable((n, n), symmetric=True)
    V = cp.Variable((n, n), symmetric=True)
    #Q = cp.Variable((n, n), symmetric=True)
    #U = cp.Variable((n, n), symmetric=True)
    v = cp.Variable(n)
    #h = cp.Variable(n)

    #lambda_param = lambda_values.loc['lambda', current_date.strftime('%Y/%m')] = last_lambda
    lambda_param = calculate_lambda_RW(state_transition_matrix, last_lambda) # 使用轮盘赌计算lambda参数
    last_lambda = lambda_param # 更新当前lambda值
    theta = 0.05  # 假设theta的值,CVaR_theta

    gamma1, gamma2 = calculate_gamma(ten_year_mu_hat, ten_year_Sigma_hat, current_date.strftime('%Y/%m'), mu_hat)
    #gamma1 = pd.read_excel('轮盘赌+动态gamma/SCS/gamma_values.xlsx').set_index('date').loc[dates[current_index].strftime('%Y/%m')]['gamma1']
    #gamma2 = pd.read_excel('轮盘赌+动态gamma/SCS/gamma_values.xlsx').set_index('date').loc[dates[current_index].strftime('%Y/%m')]['gamma2']
    objective = cp.Minimize(lambda_param * alpha + p1 + gamma2 * (cp.trace(M * Sigma_hat)))

    # 将向量和数转换为二维矩阵
    v_2D = v[:, None]
    t_2D = t[None, None]
    constrain_CVaR = cp.vstack([cp.hstack([V,v_2D]),cp.hstack([v_2D.T,t_2D])])
    #constrain_CReturn = cp.vstack([cp.hstack([U,h_2D]),cp.hstack([h_2D.T,g_2D])])
    constrain_CVaR_1 = cp.vstack([cp.hstack([M, ((1/2) * (-2*M * mu_hat - 2*v + (lambda_param / theta - lambda_param + 1) * x))[:, None]]),cp.hstack([((1/2) * (-2*M * mu_hat - 2*v + (lambda_param / theta - lambda_param + 1) * x))[:, None].T,
                                                                                                           (p1 + mu_hat.T * M * mu_hat - cp.trace(Sigma_hat * V) + 2 * v.T * mu_hat - gamma1 * t + lambda_param * alpha / theta)[None,None]])])
    constrain_CVaR_2 = cp.vstack([cp.hstack([M, ((1/2) *(2*M * mu_hat + 2*v + (lambda_param - 1) * x))[:, None]]),cp.hstack([((1/2) *(2*M * mu_hat + 2*v + (lambda_param - 1) * x))[:, None].T,
                                                                                                           (p1 + mu_hat.T * M * mu_hat - cp.trace(Sigma_hat * V) + 2 * v.T * mu_hat - gamma1 * t)[None,None]])])
    #constrain_CReturn_1 = cp.vstack([cp.hstack([Q, ((1 / 2) * (x - 2 * Q * mu_hat - 2 * h))[:, None]]),cp.hstack([((1 / 2) * (x - 2 * Q * mu_hat - 2 * h))[:, None].T,
    #                                                                                                       (q1 + mu_hat.T * Q * mu_hat - cp.trace(Sigma_hat * V) + 2 * mu_hat.T * h - gamma1 * g)[None,None]])])
    constraints = [x >= 0,
                   cp.sum(x) == 1,
                   M >> 0,
                   #Q >> 0,
                   constrain_CVaR >> 0,
                   #constrain_CReturn >> 0,
                   constrain_CVaR_1 >> 0,
                   constrain_CVaR_2 >> 0,
                   #constrain_CReturn_1 >> 0
                   ]

    prob = cp.Problem(objective, constraints)
    #print(f"开始求解{current_year_index}年{current_month_index}月")
    # 设置求解器参数
    prob.solve(solver=cp.SCS, max_iters = 5000, verbose=False)

    objective_value = prob.value
    monthly_objective_values.loc['all', current_date.strftime('%Y/%m')] = objective_value

    x_value = x.value
    x_value[x_value < 0] = 0
    print(f"M:{M.value}")
    print(f"v:{v.value}")
    print(f"V:{V.value}")
    print(f"q:{t.value}")
    print(lambda_param * (alpha.value + (1 / theta) * max(-1 * np.dot(mu_hat,x_value), 0)) - (1-lambda_param)*(np.dot(mu_hat,x_value)))
    # 输出结果
    portfolio_allocations[current_date.strftime('%Y/%m')] = x_value
    # 计算投资组合的收益并保存到DataFrame中
    portfolio_return = np.dot(mu_hat, x_value)
    monthly_returns.loc['all', current_date.strftime('%Y/%m')] = portfolio_return
    portfolio_std = np.sqrt(np.dot(x_value, np.dot(Sigma_hat, x_value)))
    monthly_var.loc['all', current_date.strftime('%Y/%m')] = portfolio_std

    print(f"{current_date.strftime('%Y/%m')}的投资组合为：{x_value}，收益率为：{portfolio_return}")
    end_time = time.time()  # 记录一个月的运行时间
    print(f"{current_date.strftime('%Y/%m')}的模型求解完成，计算时间为{end_time - start_time}秒")

    monthly_data_index = [] # 清空monthly_data_index

# 将DataFrame保存到xlsx文件中
portfolio_allocations.to_excel('轮盘赌+动态gamma/SCS/行业最优投资组合（NewMCRM）.xlsx')
monthly_returns.to_excel('轮盘赌+动态gamma/SCS/最优投资组合的收益（NewMCRM）.xlsx')
monthly_var.to_excel('轮盘赌+动态gamma/SCS/最优投资组合的标准差（NewMCRM）.xlsx')
monthly_objective_values.to_excel('轮盘赌+动态gamma/SCS/目标函数值（NewMCRM）.xlsx')
