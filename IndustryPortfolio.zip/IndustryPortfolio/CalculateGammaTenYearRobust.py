import numpy as np
from scipy.optimize import minimize
from scipy.stats import multivariate_normal
import pandas as pd
import pickle
import cvxpy as cp
import os
import time
import mosek

def ten_year_data():
    df = pd.read_excel('ten_year_daily_returns.xlsx')  # 读取历史收益数据
    df_grouped = df.groupby('industry_gics').mean()  # 计算每个行业的股票每日均值
    industries = df_grouped.index.tolist()  # 获取行业列表
    n = len(industries)  # 行业数量
    dates = pd.to_datetime(df.columns[4:], format="%Y/%m/%d")# 获取日期列表

    # 初始化
    current_year_index = dates[0].year
    current_month_index = dates[0].month
    monthly_data_index = []
    current_index = 0

    # 存储每个月的均值
    monthly_means = []

    # 遍历日期
    for date in dates:
        # 获取年份和月份
        year = date.year
        month = date.month

        # 判断是否是当前月份
        if year == current_year_index and month == current_month_index:
            monthly_data_index.append(date)
            current_index += 1
        elif year == current_year_index and month > current_month_index:
            # 计算当前月的均值
            monthly_data = df_grouped.loc[:, monthly_data_index[0]:monthly_data_index[-1]]
            monthly_mean = monthly_data.mean(axis=1, skipna=True).values
            monthly_means.append(monthly_mean)

            # 更新索引
            current_month_index += 1
            monthly_data_index = [date]
        elif year == current_year_index + 1:
            # 计算最后一个月的均值
            monthly_data = df_grouped.loc[:, monthly_data_index[0]:monthly_data_index[-1]]
            monthly_mean = monthly_data.mean(axis=1, skipna=True).values
            monthly_means.append(monthly_mean)

            # 更新索引
            current_year_index += 1
            current_month_index = 1
            monthly_data_index = [date]

    # 转换成 NumPy 数组
    monthly_means = np.array(monthly_means).transpose()

    # 计算期望的经验估计
    mu_hat = monthly_means.mean(axis=1)

    # 计算协方差的经验估计
    returns_data_centered = monthly_means - mu_hat[:, np.newaxis]
    Sigma_hat = (1 / monthly_means.shape[1]) * np.dot(returns_data_centered, returns_data_centered.T)

    # 保存 mu_hat 和 Sigma_hat 到文件中
    with open('mu_hat.pkl', 'wb') as f:
        pickle.dump(mu_hat, f)
    with open('Sigma_hat.pkl', 'wb') as f:
        pickle.dump(Sigma_hat, f)

def five_year_data():
    df = pd.read_excel('ten_year_daily_returns.xlsx')  # 读取历史收益数据
    df_grouped = df.groupby('industry_gics').mean()  # 计算每个行业的股票每日均值
    industries = df_grouped.index.tolist()  # 获取行业列表
    n = len(industries)  # 行业数量
    dates = pd.to_datetime(df.columns[4:], format="%Y/%m/%d")# 获取日期列表

    # 初始化
    current_year_index = dates[0].year
    current_month_index = dates[0].month
    monthly_data_index = []
    current_index = 0

    # 存储每个月的均值
    monthly_means = []

    # 遍历日期
    for date in dates:
        # 获取年份和月份
        year = date.year
        month = date.month
        if year <= 2013:
            # 判断是否是当前月份
            if year == current_year_index and month == current_month_index:
                monthly_data_index.append(date)
                current_index += 1
            elif year == current_year_index and month > current_month_index:
                # 计算当前月的均值
                monthly_data = df_grouped.loc[:, monthly_data_index[0]:monthly_data_index[-1]]
                monthly_mean = monthly_data.mean(axis=1, skipna=True).values
                monthly_means.append(monthly_mean)

                # 更新索引
                current_month_index += 1
                monthly_data_index = [date]
            elif year == current_year_index + 1:
                # 计算最后一个月的均值
                monthly_data = df_grouped.loc[:, monthly_data_index[0]:monthly_data_index[-1]]
                monthly_mean = monthly_data.mean(axis=1, skipna=True).values
                monthly_means.append(monthly_mean)

                # 更新索引
                current_year_index += 1
                current_month_index = 1
                monthly_data_index = [date]

    # 转换成 NumPy 数组
    monthly_means = np.array(monthly_means).transpose()

    # 计算期望的经验估计
    mu_hat = monthly_means.mean(axis=1)

    # 计算协方差的经验估计
    returns_data_centered = monthly_means - mu_hat[:, np.newaxis]
    Sigma_hat = (1 / monthly_means.shape[1]) * np.dot(returns_data_centered, returns_data_centered.T)

    # 保存 mu_hat 和 Sigma_hat 到文件中
    with open('five_year_mu_hat.pkl', 'wb') as f:
        pickle.dump(mu_hat, f)
    with open('five_year_Sigma_hat.pkl', 'wb') as f:
        pickle.dump(Sigma_hat, f)

def calculate_gamma(mu_hat, Sigma_hat, current_date, current_month_means):
    start_time = time.time()  # 记录一个月的运行时间
    # 定义变量
    gamma1 = cp.Variable()
    gamma2 = cp.Variable()

    # 定义并求解第一个优化问题
    constraints1 = [cp.quad_form(current_month_means - mu_hat, np.linalg.inv(Sigma_hat)) - gamma1*10000 <= 0,
                    gamma1 >= 0]
    objective1 = cp.Minimize(gamma1)

    prob1 = cp.Problem(objective1, constraints1)
    prob1.solve()

    # 定义并求解第二个优化问题
    constraints2 = [np.outer(current_month_means - mu_hat, current_month_means - mu_hat) - len(mu_hat) * gamma2*100 * Sigma_hat << 0,
                    gamma2 >= 1]
    objective2 = cp.Minimize(gamma2)
    prob2 = cp.Problem(objective2, constraints2)
    prob2.solve()

    print(gamma1.value, gamma2.value)
    end_time = time.time()  # 记录一个月的运行时间
    print(f"gamma的计算时间为{end_time - start_time}秒")

    '''
    # 将结果追加入文件
    df_new = pd.DataFrame({'date': [current_date], 'gamma1': [gamma1.value], 'gamma2': [gamma2.value]}) # 创建一个新的 DataFrame 来存储当前的 gamma 值
    df_new.set_index('date', inplace=True)
    
    # 如果文件已经存在，读取文件并将新的DataFrame添加到旧的DataFrame中
    if os.path.exists('/Users/yinmengzi/Desktop/行业投资比例改进/轮盘赌+动态gamma/SCS/gamma_values.xlsx'):
        df_old = pd.read_excel('/Users/yinmengzi/Desktop/行业投资比例改进/轮盘赌+动态gamma/SCS/gamma_values.xlsx', index_col='date')
        df = pd.concat([df_old, df_new])
    else:
        df = df_new
    df.to_excel('/Users/yinmengzi/Desktop/行业投资比例改进/轮盘赌+动态gamma/SCS/gamma_values.xlsx')
    '''
    return gamma1.value, gamma2.value

def calculate_five_year_gamma(mu_hat, Sigma_hat, current_date, current_month_means):
    start_time = time.time()  # 记录一个月的运行时间
    # 定义变量
    gamma1 = cp.Variable()
    gamma2 = cp.Variable()

    # 定义并求解第一个优化问题
    constraints1 = [cp.quad_form(current_month_means - mu_hat, np.linalg.inv(Sigma_hat)) - gamma1 <= 0,
                    gamma1 >= 0]
    objective1 = cp.Minimize(gamma1)

    prob1 = cp.Problem(objective1, constraints1)
    prob1.solve()

    # 定义并求解第二个优化问题
    constraints2 = [np.outer(current_month_means - mu_hat, current_month_means - mu_hat) - len(mu_hat) * gamma2 * Sigma_hat << 0,
                    gamma2 >= 1]
    objective2 = cp.Minimize(gamma2)
    prob2 = cp.Problem(objective2, constraints2)
    prob2.solve()

    print(gamma1.value, gamma2.value)
    end_time = time.time()  # 记录一个月的运行时间
    print(f"gamma的计算时间为{end_time - start_time}秒")

    # 将结果追加入文件
    df_new = pd.DataFrame({'date': [current_date], 'gamma1': [gamma1.value], 'gamma2': [gamma2.value]}) # 创建一个新的 DataFrame 来存储当前的 gamma 值
    df_new.set_index('date', inplace=True)
    # 如果文件已经存在，读取文件并将新的DataFrame添加到旧的DataFrame中
    if os.path.exists('five_year_gamma_values.xlsx'):
        df_old = pd.read_excel('five_year_gamma_values.xlsx', index_col='date')
        df = pd.concat([df_old, df_new])
    else:
        df = df_new
    df.to_excel('five_year_gamma_values.xlsx')

    return gamma1.value, gamma2.value

#ten_year_data()
#five_year_data()
#one_year_data()