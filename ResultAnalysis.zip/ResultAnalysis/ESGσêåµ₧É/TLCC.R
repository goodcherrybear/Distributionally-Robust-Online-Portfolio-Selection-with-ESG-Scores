library(readxl)
library(writexl)
library(dplyr)
library(tidyr)
library(TSA)
library(ggplot2)
library(reshape2)
library(showtext)
font_families()
font_add('times','/System/Library/Fonts/Supplemental/Times New Roman.ttf')
showtext_auto()
library(grid)

# 读取数据
stock_prices <- read_excel("/Users/yinmengzi/Desktop/结果分析/ESG分析/returns.xlsx", col_types = "text")
esg_scores <- read_excel("/Users/yinmengzi/Desktop/结果分析/ESG分析/esg.xlsx", col_types = "text")
colnames(stock_prices)[-1] <- format(as.Date(as.numeric(colnames(stock_prices)[-1]), origin = "1899-12-30"), "%Y-%m-%d")
colnames(esg_scores)[-1] <- format(as.Date(as.numeric(colnames(esg_scores)[-1]), origin = "1899-12-30"), "%Y-%m-%d")
stock_prices[, -1] <- lapply(stock_prices[, -1], function(x) as.numeric(as.character(x)))
esg_scores[, -1] <- lapply(esg_scores[, -1], function(x) as.numeric(as.character(x)))
## 分股票，X轴lag，y轴窗口
# 定义窗口大小
window_size <- 30

# 初始化一个空的数据框来存储结果
acf_data <- data.frame(
  Window = integer(),
  Lag = integer(),
  Stock = character(),
  ACF = numeric()
)

# 对每只股票进行处理
for (i in unique(stock_prices$Stock)) {
  # 提取这只股票的数据
  stock_data <- stock_prices[stock_prices$Stock == i, -(1)]
  esg_data <- esg_scores[esg_scores$Stock == i, -(1)]
  print(i)
  # 对数据进行窗口化处理
  for (j in seq(1, length(stock_data) - window_size + 1)) {
    # 提取当前窗口的数据
    stock_window <- as.vector(unlist(list(stock_data[j:(j + window_size - 1)])))
    esg_window <- as.vector(unlist(list(esg_data[j:(j + window_size - 1)])))
    
    # 计算滞后相关性
    correlation <- ccf(stock_window, esg_window, plot = FALSE)
    index <- which(correlation$lag >= 1 & correlation$lag <= 30)
    correlation$lag <- correlation$lag[index]
    correlation$acf <- correlation$acf[index]
    
    # 将结果添加到数据框中
    acf_data <- rbind(acf_data, data.frame(
      Window = j,
      Lag = correlation$lag,
      Stock = i,
      ACF = correlation$acf
    ))
  }
}
write_xlsx(acf_data,'/Users/yinmengzi/Desktop/结果分析/ESG分析/WTLCC_results.xlsx')

acf_data =  read_excel('/Users/yinmengzi/Desktop/结果分析/ESG分析/WTLCC_results.xlsx')
# 筛选出最大ACF值超过0.7的股票
high_acf_stocks <- unique(acf_data[acf_data$ACF > 0.5 | acf_data$ACF < -0.5,]$Stock)
high_acf_stocks <- high_acf_stocks[!is.na(high_acf_stocks)]

for (i in high_acf_stocks) {
  # 提取每只股票的相关数据
  stock_acf_data <- subset(acf_data, Stock == i)
  
  # 获取窗口和滞后的最大值，用于标注序号
  max_window <- max(stock_acf_data$Window)
  max_lag <- max(stock_acf_data$Lag)
  
  # 创建热力图
  heat_map <- ggplot(stock_acf_data, aes(x = Lag, y = Window, fill = ACF)) +
    geom_tile() +
    scale_fill_distiller(palette = 'RdBu', na.value = "white", 
                         guide = guide_colourbar(label = TRUE, barwidth = 0.5, barheight = 15),
                         breaks = seq(-1, 1, by = 0.2), limits = c(-1, 1)) +
    labs(title = paste("Stock:", i),
         x = "Lag",
         y = "Window") +
    theme_minimal() +
    scale_x_continuous(breaks = seq(1, max_lag, by = 1)) +
    scale_y_continuous(breaks = seq(0, max_window, by = 100), trans = "reverse") +
    theme(plot.title = element_text(margin = margin(b = -5), hjust = 0.5, family = "times", color = "black", size = 14),
          legend.position = "right",
          legend.margin = margin(l = -15),
          legend.text = element_text(family = "times", color = "black", size = 14),
          panel.grid = element_blank(),
          text = element_text(family = "times", color = "black", size = 14),
          axis.text.x = element_text(margin = margin(t = -12), family = "times", color = "black", size = 14),
          axis.text.y = element_text(margin = margin(r = -12), family = "times", color = "black", size = 14)) 
  
  # 保存或显示图形
  ggsave(paste("/Users/yinmengzi/Desktop/结果分析/ESG分析/TLCC结果/", i, ".png", sep = ""), heat_map, width = 5, height = 4, dpi=600)  # 保存图形为文件
  #print(heat_map)  # 在R中显示图形
}

