import pandas as pd
import numpy as np
import matplotlib.pyplot as plt
import matplotlib.dates as mdates
from sklearn.cluster import KMeans
from scipy import stats
from statsmodels.stats.multicomp import pairwise_tukeyhsd
from matplotlib import rcParams
config = {
            "font.family": 'serif',
            "font.size": 18,# 相当于小四大小
            "mathtext.fontset": 'stix',#matplotlib渲染数学字体时使用的字体，和Times New Roman差别不大
            "font.serif": ['Songti SC'],#宋体
            'axes.unicode_minus': False # 处理负号，即-号
         }
rcParams.update(config)

# 步骤1：加载数据并进行聚类
portfolio = pd.read_excel('AEC(IMCRM).xlsx', index_col='Stock')
esg = pd.read_excel('esg.xlsx', index_col='Stock')

# 对投资组合数据进行标准化处理
portfolio_normalized = portfolio

# 轴方法确定聚类数目
def elbow():
    sse = []
    K = range(1, 11)
    for k in K:
        kmeanModel = KMeans(n_clusters=k).fit(portfolio_normalized)
        sse.append(kmeanModel.inertia_)

    # 绘制手肘曲线
    plt.plot(K, sse, 'bx-')
    plt.xlabel('k')
    plt.ylabel('SSE')
    plt.title('The Elbow Method showing the optimal k')
    plt.savefig('第二阶段投资比例与ESG得分/手肘法.png', dpi=600)
    plt.close()

#elbow()

def cluster():
    '''
    # 使用KMeans进行聚类
    kmeans = KMeans(n_clusters=4, random_state=0).fit(portfolio_normalized)
    labels = kmeans.labels_
    portfolio['Cluster'] = labels
    esg['Cluster'] = labels
    portfolio['Cluster'].to_excel('第二阶段投资比例与ESG得分/stock_cluster_results.xlsx', index=True)
    
    # 步骤2：计算每个群组的平均ESG得分并绘图
    esg_melt = esg.melt(id_vars='Cluster', var_name='Date', value_name='ESG')
    esg_melt['Date'] = pd.to_datetime(esg_melt['Date'])
    esg_mean = esg_melt.groupby(['Date', 'Cluster']).mean().reset_index()
    '''
    #esg_mean.to_excel('第二阶段投资比例与ESG得分/esg_mean.xlsx')
    # 计算每个群组的投资比例的每日平均值
    portfolio_melt = portfolio.melt(id_vars='Cluster', var_name='Date', value_name='Investment')
    portfolio_melt['Date'] = pd.to_datetime(portfolio_melt['Date'])
    portfolio_mean = portfolio_melt.groupby(['Date', 'Cluster']).mean().reset_index()
    portfolio_sum = portfolio_melt.groupby(['Date', 'Cluster']).sum().reset_index()
    #portfolio_stats = portfolio_melt.groupby('Cluster')['Investment'].agg(['mean', 'median', 'max', 'min'])
    #portfolio_mean.to_excel('第二阶段投资比例与ESG得分/portfolio_mean.xlsx')

    # 对每个群组，分别绘制ESG得分和投资比例的趋势图
    for cluster in portfolio_sum['Cluster'].unique():
        fig = plt.figure(figsize=(12, 10))
        ax1 = fig.add_subplot(111)

        cluster_data_esg = portfolio_sum[portfolio_sum['Cluster'] == cluster]
        cluster_data_investment = portfolio_mean[portfolio_mean['Cluster'] == cluster]

        # 绘制平均ESG得分的线图
        ax1.bar(cluster_data_esg['Date'], cluster_data_esg['Investment'], linewidth=2, label=f'ESG Score',
                 color='#c12e34')
        ax1.xaxis.set_major_locator(mdates.MonthLocator(bymonth=[1, 7]))
        ax1.xaxis.set_major_formatter(mdates.DateFormatter('%Y-%m'))
        ax1.set_xlim(min(cluster_data_investment['Date']), max(cluster_data_investment['Date']))
        ax1.set_ylim(0, 1)
        ax1.set_xlabel('Date')
        ax1.set_ylabel('Total allocation weight')

        # 创建第二个x轴和y轴
        ax2 = ax1.twinx()
        ax3 = ax1.twiny()

        # 绘制平均投资比例的线图
        ax2.bar(cluster_data_investment['Date'], cluster_data_investment['Investment'], linewidth=2,
                 label=f'Average allocation weight', color='#005eaa')
        ax3.plot(cluster_data_investment['Date'], cluster_data_investment['Investment'], linewidth=0)
        ax3.set_xticklabels([])
        ax3.set_xticks([])
        ax2.set_ylim(0, 1)
        #ax2.set_ylim(0, 1)
        ax2.set_ylabel('Average allocation weight')

        # 反转第二个y轴
        ax2.invert_yaxis()

        # 添加图例
        lines, labels = ax1.get_legend_handles_labels()
        lines2, labels2 = ax2.get_legend_handles_labels()
        ax2.legend(lines + lines2, labels + labels2, loc='lower right')

        #plt.title(f'ESG score and investment ratio trend for cluster {cluster + 1}')
        plt.savefig(f'第二阶段投资比例与ESG得分/Cluster{cluster}_esg', dpi=600)
        plt.close()
    '''
    # 步骤3：进行方差分析
    # 进行ANOVA
    fvalue, pvalue = stats.f_oneway(*[group["ESG"].values for name, group in esg_mean.groupby("Cluster")])
    with open('第二阶段投资比例与ESG得分/anova_results.txt', 'w') as f:
        f.write(f"ANOVA results: F={fvalue}, P={pvalue}\n")

    # 进行Tukey HSD测试（事后检验）
    tukey = pairwise_tukeyhsd(endog=esg_mean['ESG'], groups=esg_mean['Cluster'], alpha=0.05)
    print(tukey)
    with open('第二阶段投资比例与ESG得分/tukey_results.txt', 'w') as f:
        f.write(str(tukey))
    '''
cluster()