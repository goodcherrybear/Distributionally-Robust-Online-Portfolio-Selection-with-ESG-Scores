import pandas as pd
from matplotlib import rcParams
import matplotlib.ticker as ticker
config = {
    "font.family": 'serif',
    "font.size": 18,  # 相当于小四大小
    "mathtext.fontset": 'stix',  # matplotlib渲染数学字体时使用的字体，和Times New Roman差别不大
    "font.serif": ['Songti SC'],  # 宋体
    'axes.unicode_minus': False  # 处理负号，即-号
}
rcParams.update(config)

# 步骤1：加载数据并进行聚类
portfolio = pd.read_excel('AEC(IMCRM).xlsx', index_col='Stock')
esg = pd.read_excel('esg.xlsx', index_col='Stock')

# 对投资组合数据进行标准化处理
portfolio_normalized = portfolio

def cluster():
    # 计算每个群组的投资比例的每日平均值
    portfolio_melt = portfolio.melt(id_vars='Cluster', var_name='Date', value_name='Investment')
    portfolio_melt['Date'] = pd.to_datetime(portfolio_melt['Date'])
    portfolio_mean = portfolio_melt.groupby(['Date', 'Cluster']).mean().reset_index()
    portfolio_sum = portfolio_melt.groupby(['Date', 'Cluster']).sum().reset_index()
    # portfolio_stats = portfolio_melt.groupby('Cluster')['Investment'].agg(['mean', 'median', 'max', 'min'])
    # portfolio_mean.to_excel('第二阶段投资比例与ESG得分/portfolio_mean.xlsx')

    import matplotlib.pyplot as plt
    import matplotlib.gridspec as gridspec
    import matplotlib.dates as mdates

    for cluster in portfolio_sum['Cluster'].unique():
        fig = plt.figure(figsize=(12, 10))
        gs = gridspec.GridSpec(2, 1, height_ratios=[0.5, 0.5])

        ax1 = plt.subplot(gs[0])
        ax2 = plt.subplot(gs[1], sharex=ax1)

        cluster_data_esg = portfolio_sum[portfolio_sum['Cluster'] == cluster]
        cluster_data_investment = portfolio_mean[portfolio_mean['Cluster'] == cluster]

        # 绘制平均ESG得分的线图
        ax1.bar(cluster_data_esg['Date'], cluster_data_esg['Investment'], linewidth=2, label=f'ESG Score',
                color='#c12e34')
        ax1.xaxis.set_major_locator(mdates.MonthLocator(bymonth=[1, 7]))
        ax1.xaxis.set_major_formatter(mdates.DateFormatter('%Y-%m'))
        ax1.set_xlim(min(cluster_data_investment['Date']), max(cluster_data_investment['Date']))
        ax1.set_ylim(0, 1)
        ax1.set_ylabel('Total allocation weight')

        # 绘制平均投资比例的线图
        ax2.bar(cluster_data_investment['Date'], cluster_data_investment['Investment'], linewidth=2,
                label=f'Average allocation weight', color='#005eaa')
        ax2.set_ylim(0, 0.14)  # 根据您的数据调整y轴范围
        ax2.set_xlabel('Date')
        ax2.set_ylabel('Average allocation weight')

        # 设置y轴刻度格式
        ax1.yaxis.set_major_formatter(ticker.FormatStrFormatter('%.2f'))
        ax2.yaxis.set_major_formatter(ticker.FormatStrFormatter('%.2f'))

        # 隐藏y轴的最大值
        #ax1.set_yticks(ax1.get_yticks()[:-1])
        ax2.set_yticks(ax2.get_yticks()[:-1])

        plt.subplots_adjust(hspace=0)  # 不留间距
        plt.savefig(f'第二阶段投资比例与ESG得分/Cluster{cluster}_esg', dpi=600)
        plt.close()
cluster()