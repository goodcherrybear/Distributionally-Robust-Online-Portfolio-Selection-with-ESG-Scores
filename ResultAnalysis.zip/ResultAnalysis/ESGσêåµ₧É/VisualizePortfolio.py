import pandas as pd
import matplotlib.pyplot as plt
import matplotlib.dates as mdates

# 读取数据
data = pd.read_excel('AEC(IMCRM).xlsx', index_col='Stock', parse_dates=True, sheet_name='Sheet2')
#data = data.T

for industry, group in data.groupby('industry'):
    print(industry)
    list_data = []
    group = group.drop('industry', axis=1)
    for date_index, date in enumerate(group.columns):
        # 获取股票代码的索引
        for stock_index, stock in enumerate(group.index):
            # 获取投资比例
            ratio = group.loc[stock, date]
            # 将结果添加到列表
            list_data.append([date_index, stock_index, ratio])
    print(list_data)

'''
for industry, group in data.groupby('industry'):
    bottom = 0
    plt.figure(figsize=(18, 6))
    group = group.drop('industry', axis=1)
    for stock in group.index:
        plt.bar(group.columns, group.loc[stock], label=stock, bottom=bottom, alpha=0.8)
        bottom += group.loc[stock]
    plt.show()
    break

    # 创建一个新的figure
    fig, ax = plt.subplots(figsize=(18, 6))
    # 使用stackplot函数创建堆叠图
    plt.stackplot(data.columns[1:], data.iloc[:,1:].values, labels=data.index,alpha=1)
    ax.set_xlim([min(data.columns[1:]), max(data.columns[1:])])
    ax.set_ylim([0, 1])
    # 添加图例和标题
    plt.legend(loc='upper left', bbox_to_anchor=(1, 1))
    plt.title('Stage 1: Optimal industry portfolios (Sequential MCRM)')
    plt.xticks(rotation=45)
    plt.show()
'''
'''
    plt.figure(figsize=(18, 6))
    group.drop('industry', axis=1).T.plot(label=industry)
    plt.title('Stock Investment Over Time by Industry')
    plt.xlabel('Date')
    plt.ylabel('Investment Ratio')
    plt.legend(title='Industry')
    plt.savefig(f'第二阶段投资比例可视化/行业{industry}投资比例.png', dpi=600)
    plt.close()

data.plot(kind='box', figsize=(10, 6))
plt.title('Distribution of Stock Investment Ratios')
plt.ylabel('Investment Ratio')
plt.savefig('第二阶段投资比例可视化/散点图.png', dpi=600)
plt.close()
'''


