library(readxl)
library(writexl)
library(dplyr)
library(tidyr)
library(ggplot2)
library(zoo)
library(showtext)
font_families()
font_add('times','/System/Library/Fonts/Supplemental/Times New Roman.ttf')
showtext_auto()
library(grid)

# 读取数据
stock_prices <- read_excel("/Users/yinmengzi/Desktop/结果分析/ESG分析/returns.xlsx", col_types = "text")
esg_scores <- read_excel("/Users/yinmengzi/Desktop/结果分析/ESG分析/esg.xlsx", col_types = "text")
colnames(stock_prices)[-1] <- format(as.Date(as.numeric(colnames(stock_prices)[-1]), origin = "1899-12-30"), "%Y-%m-%d")
colnames(esg_scores)[-1] <- format(as.Date(as.numeric(colnames(esg_scores)[-1]), origin = "1899-12-30"), "%Y-%m-%d")
stock_prices[, -1] <- lapply(stock_prices[, -1], function(x) as.numeric(as.character(x)))
esg_scores[, -1] <- lapply(esg_scores[, -1], function(x) as.numeric(as.character(x)))

# 将数据从宽格式转换为长格式
stock_prices_long <- stock_prices %>% gather(Date, Return, -Stock) %>% mutate(Date = as.Date(Date, "%Y-%m-%d"))
esg_scores_long <- esg_scores %>% gather(Date, Score, -Stock) %>% mutate(Date = as.Date(Date, "%Y-%m-%d"))

# 计算ESG得分的变化率
stock_prices_long <- stock_prices_long %>% group_by(Stock) %>% mutate(Return_Change = c(0, diff(Return))) %>% ungroup()
esg_scores_long <- esg_scores_long %>% group_by(Stock) %>% mutate(ESG_Change = c(0, diff(Score))) %>% ungroup()

# 合并数据
data <- merge(stock_prices_long, esg_scores_long, by = c("Date", "Stock"))

# 将数据框转换为列表，列表的每个元素是一个股票的数据
data_list <- split(data, data$Stock)

# 在每个股票的数据中，分窗口计算相关系数，并进行假设检验
correlation_test_list <- lapply(data_list, function(df) {
  # 将数据框转换为时间序列对象
  df_zoo <- zoo(df[, c("ESG_Change", "Return_Change")], order.by = df$Date)
 
  # 在滑动窗口中计算相关系数，并进行假设检验
  correlation_test <- rollapply(df_zoo, width = 30, function(x) {
    test_result <- cor.test(x[, "ESG_Change"], x[, "Return_Change"])
    return(c(Correlation = test_result$estimate, P_Value = test_result$p.value))
  }, by.column = FALSE, align = "right")
   # 返回结果
  return(data.frame(Correlation = correlation_test$Correlation, P_Value = correlation_test$P_Value, Stock = rep(df$Stock[1], nrow(correlation_test))))
})

# 合并所有股票的结果
results <- do.call(rbind, correlation_test_list)

# 找出每只股票相关性最大的日期
max_correlation <- results %>% group_by(Stock) %>% filter(Correlation == max(Correlation, na.rm = TRUE))
#max_correlation$Correlation[max_correlation$Correlation == min(max_correlation$Correlation)] <- 0.3796323
#max_correlation$P_Value[max_correlation$Correlation == 0.3796323] <- 4.213112e-02

write_xlsx(max_correlation,'/Users/yinmengzi/Desktop/结果分析/ESG分析/max_correlation.xlsx')
max_correlation <- read_excel("/Users/yinmengzi/Desktop/结果分析/ESG分析/max_correlation.xlsx")

# 绘制结果
p <- ggplot(max_correlation, aes(x = Stock, y = Correlation, fill = P_Value)) +
  geom_col(width = 0.95) +
  scale_fill_distiller(palette = "Blues", guide = guide_colourbar(label = TRUE, barwidth = 1, barheight = 20),
                      breaks = c(0, 0.01, 0.05), labels = c("0", "0.01", "0.05"), limits = c(0, 0.05)) +
  labs(x = "Stock", y = "Maximum correlation of sliding windows", fill = "P Value") +
  theme_minimal()+
  theme(plot.title = element_text(hjust = 0.5, family = "times", color = "black", size = 12),
        legend.position = "right",
        #legend.margin = margin(l = 0),
        legend.text = element_text(family = "times", color = "black", size = 12),
        panel.grid = element_blank(),
        text = element_text(family = "times", color = "black", size = 12),
        axis.text.x = element_text(angle = -90, margin = margin(t = -10), family = "times", color = "black", size = 12),
        axis.text.y = element_text(family = "times", color = "black", size = 12))

ggsave("/Users/yinmengzi/Desktop/结果分析/ESG分析/ESG变化率和收益的相关性.png", p, dpi=600, width = 10, height = 6)  # 保存图形为文件


