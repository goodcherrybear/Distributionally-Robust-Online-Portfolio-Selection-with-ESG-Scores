import pandas as pd
import numpy as np
from scipy.optimize import minimize
import datetime
import os
import glob

def calculate_metrics(strategy_portfolio):
    risk_free_rate = 1
    cumulative_wealth = pd.read_excel(f"修正/传统方法/累积收益/cumulative_wealth({strategy_portfolio}).xlsx")['累积收益']
    returns = cumulative_wealth.div(cumulative_wealth.shift())
    returns = returns.fillna(1)
    real_returns = returns - 1

    # 读取投资组合权重数据
    portfolio_weights = pd.read_excel(f'修正/传统方法/投资组合/{strategy_portfolio}.xlsx', index_col=0)
    portfolio_weights = portfolio_weights.dropna(how='all', axis=0).dropna(how='all', axis=1)

    # 计算换手率
    theta = 0.0005
    cumulative_time = portfolio_weights.shape[1]
    s_t = 0
    for t in range(2, cumulative_time):
        b_t = portfolio_weights.iloc[:, t]  # 所有股票t时刻的分配比例
        b_tminus1 = portfolio_weights.iloc[:, t - 1]  # 所有股票t-1时刻的分配比例

        # 解交易成本k的目标函数
        def objective_function(k):
            l1_norm = np.sum(np.abs(b_tminus1 - b_t * k))
            return 1 - k - theta * l1_norm

        # 定义距离约束
        constraint = (
            {'type': 'ineq', 'fun': lambda k: 1e-20 - np.abs(1 - k - theta * np.sum(np.abs(b_tminus1 - b_t * k)))})
        k = minimize(objective_function, 1, bounds=[(0, 1)], constraints=constraint).x
        s_t += np.sum(np.abs(b_tminus1 - b_t * k))

    turnover = s_t / (2 * cumulative_time)

    # 计算权重波动率（每只股票的标准差，所有标准差的均值）
    weight_volatility = portfolio_weights.std(axis=1).mean()

    # 计算参数灵敏度（计算策略变化前后的权重变化率然后求每只股票变化率的均值再求全部股票的均值）
    changed_portfolio_weights = pd.read_excel(
        f'修正/传统方法/投资组合/{strategy_portfolio}(ChangeReturn).xlsx', index_col=0)
    # 计算权重变化
    weight_changes = np.abs(changed_portfolio_weights - portfolio_weights)
    # 计算每只股票变化率的均值
    stock_mean_changes = weight_changes.mean(axis=1)
    # 计算全部股票的均值
    parameter_sensitivity = stock_mean_changes.mean()

    # 计算最大回撤（MDD）
    drawdowns = np.minimum(real_returns - 1, 0)  # 只考虑收益小于1的情况
    MDD = np.sqrt(np.mean(drawdowns ** 2))  # 根据公式计算MDD

    # 计算VaR
    confidence_level = 0.95
    VaR = - np.percentile(real_returns, 100*(1-confidence_level))

    # 计算CVaR
    CVaR = - np.mean(real_returns[real_returns < - VaR])

    # 计算超额收益
    excess_returns = returns - benchmark_returns

    # 计算Beta, Alpha
    Beta = returns.cov(benchmark_returns) / np.var(benchmark_returns)
    Alpha = np.mean(returns)- [risk_free_rate + Beta*(np.mean(benchmark_returns) - risk_free_rate)]

    # 计算夏普比率
    sharpe_ratio = (np.mean(returns) - risk_free_rate) / np.std(returns)

    # 计算信息比率
    information_ratio = np.mean(excess_returns) / np.std(excess_returns)

    # 计算卡玛比率
    calmar_ratio = (np.mean(returns) - risk_free_rate) / MDD

    # 计算特雷诺比率
    Treynor_ratio = (np.mean(returns) - risk_free_rate) / Beta

    # 计算M2比率
    M2_ratio =(np.mean(returns) - risk_free_rate) * (np.std(benchmark_returns) / np.std(returns)) - (np.mean(benchmark_returns) - risk_free_rate)

    return {
        'Model of Stage 1': strategy_portfolio,
        'Cumulative wealth': float(list(cumulative_wealth)[-1]),
        'Turnover': turnover,
        'Weight volatility': weight_volatility,
        'Parameter sensitivity': parameter_sensitivity,
        'MDD': MDD,
        'SR': sharpe_ratio,
    }

if __name__ == '__main__':
    # 获取每种策略的结果文件
    strategy_portfolio_files = [os.path.basename(file) for file in glob.glob(os.path.join('修正/传统方法/投资组合/', '*'))]
    strategy_portfolios = []
    for file in strategy_portfolio_files:
        strategy = file.split('.')[0]
        if strategy.split('(')[-1] != 'ChangeReturn)':
            strategy_portfolios.append(strategy)
    returns_df = pd.read_excel("returns.xlsx") # 读取收益率数据
    returns_df.replace(0, np.nan, inplace=True)
    returns_df.bfill(inplace=True)

    # 计算每种策略的累积收益
    all_cumulative_wealth = pd.DataFrame() # 保存全部策略的累积收益
    for strategy in strategy_portfolios:
        cumulative_wealth_df = pd.read_excel(f'修正/传统方法/累积收益/cumulative_wealth({strategy}).xlsx')
        cumulative_wealth_df.rename(columns={'累积收益': strategy}, inplace=True)

        if all_cumulative_wealth.empty:
            all_cumulative_wealth = cumulative_wealth_df
        else:
            all_cumulative_wealth = pd.merge(all_cumulative_wealth, cumulative_wealth_df, on='Date', how='left')

    all_cumulative_wealth.reset_index(drop=True).to_excel(f'修正/传统方法/累积收益(Change).xlsx', index=False)

    # benchmark的每日收益向量
    cumulative_wealth = pd.read_excel(f"修正/累积收益/cumulative_wealth(BAH).xlsx")['累积收益']
    benchmark_returns = cumulative_wealth.div(cumulative_wealth.shift())

    # 计算每种策略的评价指标
    metrics_df = pd.DataFrame() # 保存全部策略的评价指标
    for strategy in strategy_portfolios:
        metrics = calculate_metrics(strategy)
        metrics_df = metrics_df.append(metrics, ignore_index=True)
    # 重新排序
    metrics_df.reset_index(drop=True).to_excel('修正/传统方法/评估结果(Change).xlsx', index=False)