import numpy as np
import pandas as pd
from scipy.optimize import minimize
import cvxpy as cp
import datetime


def olmar1_with_industry_constraint(returns_df, portfolio_allocations, industries, window=5, epsilon=10):
    # 获取股票数量和时间周期数
    num_assets = len(returns_df)
    num_periods = len([col for col in returns_df.columns if col not in ['Stock', 'Industry']])
    last_valid_month = portfolio_allocations.columns[-1]  # 获取行业投资组合数据的最后一个有效月份

    # 筛选出日期列名
    date_columns = [col for col in returns_df.columns if col not in ['Stock', 'Industry']]
    returns = returns_df[date_columns].values.T

    # 初始化权重
    weights = np.ones(num_assets) / num_assets
    daily_portfolios = {}

    for t in range(1, num_periods):
        # 获取当前日期
        date = pd.to_datetime(date_columns[t - 1])
        month_str = date.strftime('%Y/%m')
        if month_str > last_valid_month:
            month_str = last_valid_month

        # 计算当前时间步的价格相对向量
        x_t = returns[t - 1]

        # 计算移动平均线
        if t < window:
            x_bar = np.mean(returns[:t], axis=0)
        else:
            x_bar = np.mean(returns[t - window:t], axis=0)

        # 计算期望相对收益
        m_t = np.dot(weights, x_t)

        # 计算步长
        gap = epsilon - m_t
        denominator = np.sum((x_t - x_bar) ** 2)
        if denominator == 0:
            lambda_t = 0
        else:
            lambda_t = max(0, gap / denominator)

        # 更新权重
        new_weights = weights + lambda_t * (x_t - x_bar)

        # 定义优化变量
        w = cp.Variable(num_assets)

        # 目标函数：最小化新权重与优化后权重的差异
        objective = cp.Minimize(cp.sum_squares(w - new_weights))

        # 基本约束
        constraints = [
            cp.sum(w) == 1,
            w >= 0
        ]

        # 行业约束
        for industry in industries:
            industry_stocks = returns_df[returns_df['Industry'] == industry]['Stock']
            industry_indices = [returns_df[returns_df['Stock'] == stock].index[0] for stock in industry_stocks]
            industry_ratio = float(
                portfolio_allocations[portfolio_allocations['行业'] == industry][month_str].iloc[0])
            constraints.append(cp.sum(w[industry_indices]) == industry_ratio)

        # 求解优化问题
        prob = cp.Problem(objective, constraints)
        prob.solve()
        weights = w.value
        if weights is None:
            weights = np.ones(num_assets) / num_assets
        weights[np.isnan(weights)] = 0

        # 求解后处理函数
        def normalize_weights(weights):
            # 将负数设为 0
            weights = np.maximum(weights, 0)
            # 归一化到 [0,1] 且和为 1
            total = np.sum(weights)
            if total == 0:
                return np.ones_like(weights) / len(weights)  # 避免全零
            return weights / total

        # 后处理权重
        optimal_weights = normalize_weights(weights)
        print(f'{date}的投资组合：{optimal_weights}')
        daily_portfolios[date] = optimal_weights

    # 转换为 DataFrame 并调整格式
    daily_portfolios_df = pd.DataFrame(daily_portfolios, index=returns_df['Stock'])
    # 保存每日投资组合到文件
    daily_portfolios_df.to_excel('投资组合结果/OLMAR-1.xlsx')
    return daily_portfolios_df


# 计算累积收益
def calculate_cumulative_wealth(strategy_portfolio, returns_df):
    portfolio_allocation = pd.read_excel(f"投资组合结果/{strategy_portfolio}.xlsx")  # 最优投资组合（每只股票）
    portfolio_allocation.columns = [col if isinstance(col, datetime.datetime) or col == 'Stock' else
                                    datetime.datetime.strptime(str(col), '%Y-%m-%d %H:%M:%S') for col in
                                    portfolio_allocation.columns]
    cumulative_time = portfolio_allocation.shape[1]
    theta = 0.0005  # 交易成本率

    cumulative_wealth_df = pd.DataFrame(columns=['Date', '累积收益'])  # 存每天的累积收益
    k_df = pd.DataFrame(columns=['Date', 'k'])  # 存每天的真实资产比例
    S_tminus1 = 1
    b_tminus1_tilde = np.zeros(len(returns_df))
    for t in range(2, cumulative_time):  # 遍历每个交易日
        date = portfolio_allocation.columns[t]  # t 时刻的日期
        x_t = returns_df.loc[:, date]  # 所有股票 t 时刻的相对价格

        b_t = portfolio_allocation.iloc[:, t]  # 所有股票 t 时刻的分配比例
        b_tminus1 = portfolio_allocation.iloc[:, t - 1]  # 所有股票 t - 1 时刻的分配比例

        # 解交易成本 k 的目标函数 v
        def objective_function(k):
            l1_norm = np.sum(np.abs(b_tminus1_tilde - b_t * k))
            return 1 - k - theta * l1_norm

        constraint = ({'type': 'ineq',
                       'fun': lambda k: 1e-20 - np.abs(1 - k - theta * np.sum(np.abs(b_tminus1_tilde - b_t * k)))})
        k = minimize(objective_function, 1, bounds=[(0, 1)], constraints=constraint).x
        s_t = S_tminus1 * k * (np.dot(b_t, x_t))  # 考虑成本损失的累计收益
        S_tminus1 = s_t
        b_tminus1_tilde = b_t * x_t / (np.dot(b_t, x_t))
        print(f"{date}的累积财富为:{s_t[0]}")
        cumulative_wealth_df = pd.concat(
            [cumulative_wealth_df, pd.DataFrame({'Date': [date], '累积收益': [s_t[0]]})], ignore_index=True)
    cumulative_wealth_df.to_excel(f"累积收益/cumulative_wealth_withSection({strategy_portfolio}).xlsx", index=False)
    return cumulative_wealth_df


# 示例调用
if __name__ == "__main__":
    # 读取收益率数据
    returns_df = pd.read_excel("returns.xlsx")
    returns_df_index = returns_df.set_index("Stock")

    # 读取行业股票价格
    industrial_stock_price = pd.read_excel("Industrial_StockPrice(2019.1.1-2023.10.9).xlsx")
    df = pd.merge(returns_df, industrial_stock_price, left_on='Stock', right_on='Code')
    industry_ids = df['industry_gics'].tolist()  # 创建每个股票对应的的行业列表
    returns_df['Industry'] = industry_ids  # 将行业 ID 列表添加为新列

    # 获取行业列表
    portfolio_allocations = pd.read_excel(
        '/Users/yinmengzi/Desktop/工作1-代码/行业投资比例改进/轮盘赌+动态gamma/SCS/动态状态转移矩阵0-1/行业最优投资组合（NewMCRM）.xlsx')  # 读取行业投资比例
    portfolio_allocations.rename(columns={'Unnamed: 0': '行业'}, inplace=True)  # 将第一列的列名改为'行业'
    industries = portfolio_allocations.iloc[:, 0].tolist()

    # 执行 OLMAR - 1 策略
    olmar1_portfolio = olmar1_with_industry_constraint(returns_df, portfolio_allocations, industries)

    # 计算累积收益
    cumulative_wealth = calculate_cumulative_wealth('OLMAR-1', returns_df.set_index('Stock'))