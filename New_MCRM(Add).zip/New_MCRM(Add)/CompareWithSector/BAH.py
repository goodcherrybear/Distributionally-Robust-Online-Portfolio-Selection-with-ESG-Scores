import pandas as pd
import numpy as np
import matplotlib.pyplot as plt
from scipy.optimize import minimize
import cvxpy as cp
import warnings
warnings.filterwarnings("ignore")
import datetime

# BAH 策略实现，增加行业约束并保存每日投资组合
def bah_strategy(returns_df, portfolio_allocations, industries):
    num_assets = len(returns_df)
    initial_weights = np.ones(num_assets) / num_assets  # 初始权重
    portfolio_returns = []
    cumulative_wealth = [1]
    daily_portfolios = {}
    last_valid_month = portfolio_allocations.columns[-1]  # 获取行业投资组合数据的最后一个有效月份

    for t in range(time_gap-1125,time_gap):
        date = returns_df.columns[t]
        month_str = date.strftime('%Y/%m')

        # 检查日期是否超出行业投资组合数据范围
        if month_str > last_valid_month:
            month_str = last_valid_month

        # 调整权重以满足行业约束
        adjusted_weights = initial_weights.copy()
        for industry in industries:
            industry_stocks = returns_df_industry.loc[returns_df_industry['Industry'] == industry, 'Stock']
            industry_ratio = float(
                portfolio_allocations[portfolio_allocations['行业'] == industry][month_str].iloc[0])
            industry_indices = [returns_df[returns_df['Stock'] == stock].index[0] for stock in industry_stocks]
            industry_weights = adjusted_weights[industry_indices]
            if industry_weights.sum() != 0:
                adjustment_factor = industry_ratio / industry_weights.sum()
                adjusted_weights[industry_indices] *= adjustment_factor

        # 记录每日投资组合
        daily_portfolios[date] = adjusted_weights
        print(f'{date}的投资组合：{adjusted_weights}')

    # 转换为 DataFrame 并调整格式
    daily_portfolios_df = pd.DataFrame(daily_portfolios, index=returns_df['Stock'])
    # 保存每日投资组合到文件
    daily_portfolios_df.to_excel('投资组合结果/BAH.xlsx')

if __name__ == "__main__":
    # 读取收益率数据
    returns_df = pd.read_excel("returns.xlsx")
    time_gap = returns_df.shape[1]
    returns_df_index = returns_df.set_index("Stock")

    # 读取行业股票价格
    industrial_stock_price = pd.read_excel("Industrial_StockPrice(2019.1.1-2023.10.9).xlsx")
    df = pd.merge(returns_df, industrial_stock_price, left_on='Stock', right_on='Code')
    industry_ids = df['industry_gics'].tolist()  # 创建每个股票对应的的行业列表
    returns_df_industry = returns_df
    returns_df_industry['Industry'] = industry_ids  # 将行业 ID 列表添加为新列

    # 获取行业列表
    portfolio_allocations = pd.read_excel(
        '/Users/yinmengzi/Desktop/工作1-代码/行业投资比例改进/轮盘赌+动态gamma/SCS/动态状态转移矩阵0-1/行业最优投资组合（NewMCRM）.xlsx')  # 读取行业投资比例
    portfolio_allocations.rename(columns={'Unnamed: 0': '行业'}, inplace=True)  # 将第一列的列名改为'行业'
    industries = portfolio_allocations.iloc[:, 0].tolist()
    n = len(industries)  # 行业数量（x 长度，需要分配的比例数量）

    bah_strategy(returns_df, portfolio_allocations, industries)