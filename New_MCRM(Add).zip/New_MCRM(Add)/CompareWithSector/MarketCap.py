import pandas as pd

def market_cap_weighted_strategy(returns_df, price_df):
    num_stocks = len(returns_df)
    num_days = returns_df.shape[1] - 1  # 减去股票名称列
    daily_portfolios = {}

    for t in range(time_gap-1125,time_gap):
        date = returns_df.columns[t + 1]
        current_prices = price_df.loc[:, date]
        total_price = current_prices.sum()
        weights = current_prices / total_price
        daily_portfolios[date] = weights

    # 转换为DataFrame并保存
    daily_portfolios_df = pd.DataFrame(daily_portfolios, index=returns_df['Stock'])
    daily_portfolios_df.to_excel('MarketCap.xlsx')
    return daily_portfolios_df


if __name__ == "__main__":
    # 读取收益率数据
    returns_df = pd.read_excel("returns.xlsx")
    time_gap = returns_df.shape[1]

    # 读取价格数据
    price_df = pd.read_excel("Industrial_StockPrice(2019.1.1-2023.10.9).xlsx")
    price_df = price_df.set_index('Code').iloc[:, 4:]  # 跳过前4列，从第5列开始取价格

    # 执行策略
    result = market_cap_weighted_strategy(returns_df, price_df)