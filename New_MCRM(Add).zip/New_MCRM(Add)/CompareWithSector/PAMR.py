import numpy as np
import pandas as pd
import cvxpy as cp


def pamr_with_industry_constraint(returns_df, portfolio_allocations, industries, C=500, epsilon=0.5):
    num_assets = len(returns_df)
    num_periods = len([col for col in returns_df.columns if col not in ['Stock', 'Industry']])
    last_valid_month = portfolio_allocations.columns[-1]

    date_columns = [col for col in returns_df.columns if col not in ['Stock', 'Industry']]
    returns = returns_df[date_columns].values.T

    weights = np.ones(num_assets) / num_assets
    portfolio_values = [1]
    daily_portfolios = {}

    for t in range(time_gap-1125,time_gap):
        date = pd.to_datetime(date_columns[t - 1])
        month_str = date.strftime('%Y/%m')
        if month_str > last_valid_month:
            month_str = last_valid_month

        x_t = returns[t - 1]
        m_t = np.dot(weights, x_t)
        loss = max(0, epsilon - m_t)
        tau = loss / (np.linalg.norm(x_t - np.mean(x_t)) ** 2 + 1 / (2 * C))
        new_weights = weights + tau * (x_t - np.mean(x_t))

        w = cp.Variable(num_assets)
        objective = cp.Minimize(cp.sum_squares(w - new_weights))
        constraints = [
            cp.sum(w) == 1,
            w >= 0
        ]

        for industry in industries:
            industry_stocks = returns_df[returns_df['Industry'] == industry]['Stock']
            industry_indices = [returns_df[returns_df['Stock'] == stock].index[0] for stock in industry_stocks]
            industry_ratio = float(
                portfolio_allocations[portfolio_allocations['行业'] == industry][month_str].iloc[0])
            constraints.append(cp.sum(w[industry_indices]) == industry_ratio)

            # 求解优化问题
            prob = cp.Problem(objective, constraints)
            prob.solve()
            weights = w.value
            if weights is None:
                weights = np.ones(50) / 50
            weights[np.isnan(weights)] = 0

            # 求解后处理函数
            def normalize_weights(weights):
                # 将负数设为0
                weights = np.maximum(weights, 0)
                # 归一化到[0,1]且和为1
                total = np.sum(weights)
                if total == 0:
                    return np.ones_like(weights) / len(weights)  # 避免全零
                return weights / total

            # 后处理权重
            optimal_weights = normalize_weights(weights)
            print(f'{date}的投资组合：{optimal_weights}')
            daily_portfolios[date] = optimal_weights

    daily_portfolios_df = pd.DataFrame(daily_portfolios, index=returns_df['Stock'])
    daily_portfolios_df.to_excel('投资组合结果/PAMR-2.xlsx')

if __name__ == "__main__":
    returns_df = pd.read_excel("returns.xlsx")
    time_gap = returns_df.shape[1]
    returns_df_index = returns_df.set_index("Stock")

    industrial_stock_price = pd.read_excel("Industrial_StockPrice(2019.1.1-2023.10.9).xlsx")
    df = pd.merge(returns_df, industrial_stock_price, left_on='Stock', right_on='Code')
    industry_ids = df['industry_gics'].tolist()
    returns_df['Industry'] = industry_ids

    portfolio_allocations = pd.read_excel(
        '/Users/yinmengzi/Desktop/工作1-代码/行业投资比例改进/轮盘赌+动态gamma/SCS/动态状态转移矩阵0-1/行业最优投资组合（NewMCRM）.xlsx')
    portfolio_allocations.rename(columns={'Unnamed: 0': '行业'}, inplace=True)
    industries = portfolio_allocations.iloc[:, 0].tolist()

    pamr_with_industry_constraint(returns_df, portfolio_allocations, industries)