import pandas as pd
import numpy as np
import cvxpy as cp
import warnings
from sklearn.preprocessing import StandardScaler

warnings.filterwarnings("ignore")
import datetime


# BCRP 策略实现，增加行业约束并保存每日投资组合
def bcrp_strategy(returns_df, portfolio_allocations, industries):
    num_assets = len(returns_df)
    num_periods = len([col for col in returns_df.columns if col not in ['Stock', 'Industry']])
    last_valid_month = portfolio_allocations.columns[-1]  # 获取行业投资组合数据的最后一个有效月份

    # 筛选出日期列名
    date_columns = [col for col in returns_df.columns if col not in ['Stock', 'Industry']]

    # 将收益率数据转换为数值类型
    returns_numeric = returns_df[date_columns].apply(pd.to_numeric, errors='coerce')

    # 处理 NaN 值
    returns_numeric = returns_numeric.fillna(0)

    # 检查是否存在无穷大的值
    if not np.isfinite(returns_numeric).all().all():
        max_value = returns_numeric[np.isfinite(returns_numeric)].max().max()
        min_value = returns_numeric[np.isfinite(returns_numeric)].min().min()
        returns_numeric = returns_numeric.replace([np.inf, -np.inf], [max_value, min_value])

    # 数据标准化
    scaler = StandardScaler()
    returns_numeric_scaled = scaler.fit_transform(returns_numeric)
    returns_numeric_scaled = pd.DataFrame(returns_numeric_scaled, columns=returns_numeric.columns)

    # 计算对数累积收益率
    log_returns = np.log(1 + returns_numeric_scaled)
    total_log_returns = np.sum(log_returns, axis=1)

    # 调整累积收益率范围
    shift = np.mean(total_log_returns)
    total_log_returns -= shift
    total_returns = np.exp(total_log_returns)

    # 检查累积收益率有效性
    if not np.isfinite(total_returns).all():
        print("累积收益率中存在无效值，请检查数据。")
        return None

    # 定义优化变量
    weights = cp.Variable(num_assets)

    # 目标函数与约束
    objective = cp.Maximize(cp.log(cp.sum(weights * total_returns)))
    constraints = [
        cp.sum(weights) == 1,
        weights >= 1e-6  # 添加权重下限约束，避免零权重导致数值问题
    ]

    # 日期转换
    date_columns = pd.to_datetime(date_columns)

    # 求解后处理函数
    def normalize_weights(weights):
        # 将负数设为0
        weights = np.maximum(weights, 0)
        # 归一化到[0,1]且和为1
        total = np.sum(weights)
        if total == 0:
            return np.ones_like(weights) / len(weights)  # 避免全零
        return weights / total

    # 行业约束
    for t in range(time_gap-1125,time_gap):
        date = date_columns[t]
        month_str = date.strftime('%Y/%m')
        if month_str > last_valid_month:
            month_str = last_valid_month

        # 检查行业比例总和
        current_month = portfolio_allocations.columns[-1]
        sum_ratio = portfolio_allocations[current_month].sum()
        if not np.isclose(sum_ratio, 1):
            print(f"行业比例总和为 {sum_ratio}，需调整为 1。")
            return None

        # 构建行业约束
        industry_constraints = []
        for industry in industries:
            industry_stocks = returns_df[returns_df['Industry'] == industry]['Stock']
            industry_indices = [returns_df[returns_df['Stock'] == stock].index[0] for stock in industry_stocks]
            industry_ratio = float(
                portfolio_allocations[portfolio_allocations['行业'] == industry][month_str].iloc[0])

            if not (0 <= industry_ratio <= 1):
                print(f"行业 {industry} 的比例 {industry_ratio} 无效。")
                continue

            industry_constraints.append(cp.sum(weights[industry_indices]) == industry_ratio)

        # 合并约束并求解
        prob = cp.Problem(objective, constraints + industry_constraints)
        prob.solve(solver=cp.SCS, eps=1e-12)  # 增加求解器容差
        weight_value = weights.value
        if weight_value is None:
            weight_value = np.ones(50) / 50
        weight_value[np.isnan(weight_value)] = 0

        # 后处理权重
        optimal_weights = normalize_weights(weight_value)
        print(f'{date}的投资组合：{optimal_weights}')

    # 转换为 DataFrame 并调整格式
    daily_portfolios = {}
    for t in range(num_periods):
        date = date_columns[t]
        daily_portfolios[date] = optimal_weights
    daily_portfolios_df = pd.DataFrame(daily_portfolios, index=returns_df['Stock'])
    # 保存每日投资组合到文件
    daily_portfolios_df.to_excel('投资组合结果/BCRP.xlsx')

if __name__ == "__main__":
    # 读取收益率数据
    returns_df = pd.read_excel("returns.xlsx")
    time_gap = returns_df.shape[1]
    returns_df_index = returns_df.set_index("Stock")

    # 读取行业股票价格
    industrial_stock_price = pd.read_excel("Industrial_StockPrice(2019.1.1-2023.10.9).xlsx")
    df = pd.merge(returns_df, industrial_stock_price, left_on='Stock', right_on='Code')
    industry_ids = df['industry_gics'].tolist()  # 创建每个股票对应的的行业列表
    returns_df['Industry'] = industry_ids  # 将行业 ID 列表添加为新列

    # 获取行业列表
    portfolio_allocations = pd.read_excel(
        '/Users/yinmengzi/Desktop/工作1-代码/行业投资比例改进/轮盘赌+动态gamma/SCS/动态状态转移矩阵0-1/行业最优投资组合（NewMCRM）.xlsx')  # 读取行业投资比例
    portfolio_allocations.rename(columns={'Unnamed: 0': '行业'}, inplace=True)  # 将第一列的列名改为'行业'
    industries = portfolio_allocations.iloc[:, 0].tolist()
    n = len(industries)  # 行业数量（x 长度，需要分配的比例数量）

    bcrp_strategy(returns_df, portfolio_allocations, industries)