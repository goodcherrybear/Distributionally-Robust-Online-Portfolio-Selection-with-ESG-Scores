import pandas as pd
import matplotlib.pyplot as plt
import seaborn as sns
from sympy import latex,symbols
import os
from matplotlib import rcParams
config = {
            "font.family": 'serif',
            "font.size": 10,# 相当于小四大小
            "mathtext.fontset": 'stix',#matplotlib渲染数学字体时使用的字体，和Times New Roman差别不大
            "font.serif": ['Songti SC'],#宋体
            'axes.unicode_minus': False # 处理负号，即-号
         }
rcParams.update(config)

results = pd.DataFrame() # 创建一个空的DataFrame来存储改变eta、L的累积收益结果

# 遍历文件夹中的所有文件
for filename in os.listdir('修正/改变eta、L的累积收益'):
    if filename.endswith('.xlsx'):
        eta, L = map(float, filename.replace('cumulative_wealth_eta', '').replace('.xlsx', '').split('_L')) # 从文件名中提取eta和L的值
        # 获取最后一天的累积收益
        df = pd.read_excel(os.path.join('修正/改变eta、L的累积收益', filename))
        last_day_cumulative_wealth = df.iloc[-1]['累积收益']
        results = results.append({'eta': eta, 'L': L, '累积收益': last_day_cumulative_wealth}, ignore_index=True)
results = results.sort_values('L')
heatmap_data = results.pivot('L', 'eta', '累积收益') # 创建一个矩阵来存储热力图的数据

# 创建热力图
fig, ax = plt.subplots(figsize=(10, 4))
sns.heatmap(heatmap_data,  annot=True, fmt=".4f", cmap='YlOrRd', ax=ax, yticklabels=True, cbar_kws={'pad': 0.01})
ax.set_aspect(1)
plt.gca().invert_yaxis()
#plt.title(f'Cumulative Wealth with \u03B7 and L Changed')
plt.xlabel(f'\u03B7')
plt.ylabel('L')

#ax.set_aspect(2)
plt.savefig('修正/改变eta、L的累积收益/改变eta、L的累积收益.png',dpi=600)
plt.close()
