import numpy as np
import pandas as pd
import numpy as np
from scipy.optimize import minimize
import cvxpy as cp
import warnings
warnings.filterwarnings("ignore")
from BetterARIMA import arima_with_lagged_esg
import datetime
import os
import openpyxl

# 读取收益率数据
returns_df = pd.read_excel("returns.xlsx")
returns_df.replace(0, np.nan, inplace=True)
returns_df.bfill(inplace=True)

theta = 0.0005 # 交易成本率
for lambda_param in range(0,20):
    #portfolio_allocation = pd.read_excel("/Users/yinmengzi/Desktop/OLPS考虑交易成本(New_MCRM)/改变lambda的投资组合/MyAEC_lambda_0.2.xlsx")
    portfolio_allocation = pd.read_excel(f"修正/改变轮盘赌lambda动态状态转移矩阵0-1的投资组合/MyAEC_lambda_{lambda_param}.xlsx")
    portfolio_allocation.columns = [col if isinstance(col, datetime.datetime) or col == 'Stock' else datetime.datetime.strptime(col, '%Y/%m/%d') for col in portfolio_allocation.columns]
    cumulative_time = portfolio_allocation.shape[1]

    cumulative_wealth_df = pd.DataFrame(columns=['Date', '累积收益'])  # 存每天的累积收益
    k_df = pd.DataFrame(columns=['Date', 'k'])  # 存每天的真实资产比例
    S_tminus1 = 1

    cumulative_wealth_df = cumulative_wealth_df.append({'Date': portfolio_allocation.columns[1], '累积收益': S_tminus1}, ignore_index=True)

    for t in range(2, cumulative_time):  # 遍历每个交易日
        date = portfolio_allocation.columns[t]  # t时刻的日期
        x_t = returns_df.loc[:, date]  # 所有股票t时刻的相对价格

        b_t = portfolio_allocation.iloc[:, t]  # 所有股票t时刻的分配比例
        b_tminus1 = portfolio_allocation.iloc[:, t - 1]  # 所有股票t-1时刻的分配比例

        # 解交易成本k的目标函数
        def objective_function(k):
            l1_norm = np.sum(np.abs(b_tminus1 - b_t * k))
            return 1 - k - theta * l1_norm

        # 定义距离约束
        constraint = (
        {'type': 'ineq', 'fun': lambda k: 1e-20 - np.abs(1 - k - theta * np.sum(np.abs(b_tminus1 - b_t * k)))})
        k = minimize(objective_function, 1, bounds=[(0, 1)], constraints=constraint).x
        s_t = S_tminus1 * k * (np.dot(b_t.T, x_t))  # 考虑成本损失的累计收益
        S_tminus1 = s_t

        print(f"{date}的累积财富为:{s_t[0]}")
        cumulative_wealth_df = cumulative_wealth_df.append({'Date': date, '累积收益': s_t[0]}, ignore_index=True)
    cumulative_wealth_df.to_excel(f"修正/改变轮盘赌lambda动态状态转移矩阵0-1的累积收益/cumulative_wealth_lambda_{lambda_param}.xlsx",index=False)

    #cumulative_wealth_df.to_excel(f"/Users/yinmengzi/Desktop/OLPS考虑交易成本(New_MCRM)/改变lambda的累积收益/cumulative_wealth_lambda_{lambda_param}.xlsx", index=False)