import pandas as pd
import matplotlib.pyplot as plt
import seaborn as sns
import os
import numpy as np
from matplotlib import rcParams
config = {
            "font.family": 'serif',
            "font.size": 8,# 相当于小四大小
            "mathtext.fontset": 'stix',#matplotlib渲染数学字体时使用的字体，和Times New Roman差别不大
            "font.serif": ['Songti SC'],#宋体
            'axes.unicode_minus': False # 处理负号，即-号
         }
rcParams.update(config)

def Visualize_lambda_line():
    all_data = pd.DataFrame()  # 创建一个空的DataFrame来存储所有的数据
    # 遍历文件夹中的每个文件
    for file in files:
        data = pd.read_excel(os.path.join(folder_path, file))
        lambda_value = round(float(file.split('_')[-1].rstrip('.xlsx')),1) # 从文件名中提取lambda的值
        all_data[lambda_value] = data['累积收益'] # 将累积收益列添加到all_data DataFrame中，列名为lambda的值

    all_data = all_data.reindex(sorted(all_data.columns, key=lambda x:float(x)), axis=1) # 对列进行排序，以确保图例的顺序按照数字顺序
    #print(all_data)
    all_data['平均值'] = all_data.mean(axis=1) # 计算所有结果的平均值，并添加到DataFrame中

    #绘制折线图
    plt.figure(figsize=(10, 6))
    colors = plt.cm.viridis(np.linspace(0, 1, len(all_data.columns))) # 创建一个颜色映射
    for i, column in enumerate(all_data.columns):
        plt.plot(all_data[column], color=colors[i], label=column)
    plt.legend(ncol=3, loc='upper left')
    plt.savefig('改变lambda的累积收益/改变lambda的累积收益（折线图）.png',dpi=600)
    plt.close()

def Visualize_lambda_heat():
    folder_path = "修正/改变lambda的累积收益"
    files = [f for f in os.listdir(folder_path) if f.endswith('.xlsx')]
    folder_path_old = '/Users/yinmengzi/Desktop/工作1-代码/OLPS考虑交易成本/修正/改变lambda的累积收益'
    files_old = [f for f in os.listdir(folder_path_old) if f.endswith('.xlsx')]

    all_data = pd.DataFrame()  # 创建一个空的DataFrame来存储所有的数据
    for file in files_old:
        data = pd.read_excel(os.path.join(folder_path_old, file))
        lambda_value = float(file.split('_')[-1].rstrip('.xlsx')) # 从文件名中提取lambda的值
        all_data.loc[lambda_value,'MCRM Cumulative Wealth'] = data.iloc[-1]['累积收益']  # 将累积收益列添加到all_data DataFrame中，列名为lambda的值
    for file in files:
        data = pd.read_excel(os.path.join(folder_path, file))
        lambda_value = float(file.split('_')[-1].rstrip('.xlsx')) # 从文件名中提取lambda的值
        all_data.loc[lambda_value,'New MCRM Cumulative Wealth'] = data.iloc[-1]['累积收益']  # 将累积收益列添加到all_data DataFrame中，列名为lambda的值
    all_data = all_data.reindex(sorted(all_data.index, key=lambda x: x), axis=0)  # 对列进行排序，以确保图例的顺序按照数字顺序

    # 绘制热力图
    fig, ax = plt.subplots(figsize=(10, 4))
    sns.heatmap(all_data.T, annot=True, fmt=".4f", cmap='YlOrRd', ax=ax, cbar_kws={"shrink": 0.4, 'pad': 0.01})
    ax.set_xlabel('\u03BB', labelpad=5)
    ax.set_yticklabels(['DROPS-1','DROPS-2'],va='center',rotation=90)
    ax.xaxis.set_ticks_position('none')
    ax.yaxis.set_ticks_position('none')
    ax.set_aspect(1)
    #plt.title(f'Cumulative Wealth with \u03BB Changed')
    #plt.show()
    plt.savefig('修正/改变lambda的累积收益/ChangeFixedLambda.png',dpi=600)
    plt.close()

def Visualize_lambda_fix_heat():
    folder_path = "修正/改变lambda的累积收益"  # 文件夹路径
    files = [f for f in os.listdir(folder_path) if f.endswith('.xlsx')]  # 获取文件夹中的所有文件

    all_data = pd.DataFrame()  # 创建一个空的DataFrame来存储所有的数据
    for file in files:
        data = pd.read_excel(os.path.join(folder_path, file))
        lambda_value = round(float(file.split('_')[-1].rstrip('.xlsx')),1) # 从文件名中提取lambda的值
        all_data.loc[lambda_value,'New MCRM Cumulative Wealth'] = data.iloc[-1]['累积收益']  # 将累积收益列添加到all_data DataFrame中，列名为lambda的值

    all_data = all_data.reindex(sorted(all_data.index, key=lambda x: x), axis=0)  # 对列进行排序，以确保图例的顺序按照数字顺序

    # 绘制热力图
    fig, ax = plt.subplots(figsize=(10, 4))
    sns.heatmap(all_data.T, annot=True, fmt=".4f", cmap='YlOrRd', ax=ax, yticklabels=False, cbar_kws={"shrink": 0.5})
    ax.set_xlabel('\u03BB')
    ax.set_ylabel('TSDROPS-2',labelpad=5)
    ax.xaxis.set_ticks_position('none')
    ax.yaxis.set_ticks_position('none')
    ax.set_aspect(2)
    plt.title(f'Cumulative Wealth with \u03BB Changed')
    #plt.show()
    plt.savefig('修正/改变lambda的累积收益/改变lambda的累积收益（热力图）.png',dpi=600)
    plt.close()

#Visualize_lambda_line()
Visualize_lambda_heat()
#Visualize_lambda_fix_heat()
