import pandas as pd
import numpy as np
import warnings
warnings.filterwarnings("ignore")
import datetime
import sympy as sp
import os
import glob
from scipy.optimize import minimize

# 读取收益率数据
returns_df = pd.read_excel("returns.xlsx")
returns_df.replace(0, np.nan, inplace=True)
returns_df.bfill(inplace=True)

strategy_portfolio_files = [os.path.basename(file) for file in glob.glob(os.path.join('修正/对比策略结果/', '*'))]
strategy_portfolios = [file.split('.')[0] for file in strategy_portfolio_files]

theta_values = [0, 0.0005, 0.001, 0.0025, 0.005, 0.01]
cumulative_wealth_df = pd.DataFrame(columns=['策略']+theta_values)
cumulative_wealth_df['策略'] = strategy_portfolios
cumulative_wealth_df.set_index('策略', inplace=True)

for theta in theta_values:
    for strategy in strategy_portfolios:
        portfolio_allocation = pd.read_excel(f'修正/对比策略结果/{strategy}.xlsx')
        portfolio_allocation.columns = [col if isinstance(col, datetime.datetime) or col == 'Stock' else datetime.datetime.strptime(col, '%Y/%m/%d') for col in portfolio_allocation.columns]
        cumulative_time = portfolio_allocation.shape[1]

        k_df = pd.DataFrame(columns=['Date', 'k'])  # 存每天的真实资产比例
        S_tminus1 = 1
        b_tminus1_tilde = np.zeros(50)
        for t in range(2, cumulative_time):  # 遍历每个交易日
            date = portfolio_allocation.columns[t]  # t时刻的日期
            x_t = returns_df.loc[:, date]  # 所有股票t时刻的相对价格

            b_t = portfolio_allocation.iloc[:, t]  # 所有股票t时刻的分配比例
            b_tminus1 = portfolio_allocation.iloc[:, t - 1]  # 所有股票t-1时刻的分配比例

            # 解交易成本k的目标函数v
            def objective_function(k):
                l1_norm = np.sum(np.abs(b_tminus1_tilde - b_t * k))
                return 1 - k - theta * l1_norm

            constraint = ({'type': 'ineq','fun': lambda k: 1e-20 - np.abs(1 - k - theta * np.sum(np.abs(b_tminus1_tilde - b_t * k)))})
            k = minimize(objective_function, 1, bounds=[(0, 1)], constraints=constraint).x
            s_t = S_tminus1 * k * (np.dot(b_t, x_t))  # 考虑成本损失的累计收益
            S_tminus1 = s_t
            b_tminus1_tilde = b_t * x_t / (np.dot(b_t, x_t))
            print(f"{date}的累积财富为:{s_t[0]}")
        cumulative_wealth_df.loc[strategy, theta] = s_t[0]
        #cumulative_wealth_df = cumulative_wealth_df.append({'策略': strategy, theta: s_t[0]}, ignore_index=True)
        print(cumulative_wealth_df)
order_df = pd.read_excel('/Users/yinmengzi/Desktop/策略.xlsx')
order = order_df['策略'].tolist()
cumulative_wealth_df = cumulative_wealth_df.reindex(order)
cumulative_wealth_df.to_excel('修正/改变theta的累积收益/cumulative_wealth_theta.xlsx',index=True)
