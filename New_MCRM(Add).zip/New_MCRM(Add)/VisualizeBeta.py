import pandas as pd
import matplotlib.pyplot as plt
import seaborn as sns
import os
import numpy as np
import matplotlib.dates as mdates
from matplotlib import rcParams
from matplotlib.colors import LinearSegmentedColormap
config = {
            "font.family": 'serif',
            "font.size": 10,# 相当于小四大小
            "mathtext.fontset": 'stix',#matplotlib渲染数学字体时使用的字体，和Times New Roman差别不大
            "font.serif": ['Songti SC'],#宋体
            'axes.unicode_minus': False # 处理负号，即-号
         }
rcParams.update(config)

def Visualize_lambda_line():
    folder_path = "修正/改变CVaR的beta/累积收益"
    files = [f for f in os.listdir(folder_path) if f.endswith('.xlsx')]

    all_data = pd.DataFrame()  # 创建一个空的DataFrame来存储所有的数据
    for file in files:
        data = pd.read_excel(os.path.join(folder_path, file))
        lambda_value = float(file.split('beta')[-1].rstrip(')).xlsx')) # 从文件名中提取lambda的值
        all_data[lambda_value] = data['累积收益'] # 将累积收益列添加到all_data DataFrame中，列名为lambda的值

    all_data = all_data.reindex(sorted(all_data.columns, key=lambda x:float(x)), axis=1) # 对列进行排序，以确保图例的顺序按照数字顺序
    all_data.index = data['Date']
    #all_data['平均值'] = all_data.mean(axis=1) # 计算所有结果的平均值，并添加到DataFrame中

    #绘制折线图
    fig, ax = plt.subplots(figsize=(10, 6))
    colors = plt.cm.Set1.colors + plt.cm.Set2.colors + plt.cm.Set3.colors  # 创建一个颜色映射
    for i, column in enumerate(all_data.columns):
        ax.plot(all_data[column], color=colors[i], label=column)

    ax.xaxis.set_major_formatter(mdates.DateFormatter('%Y/%m'))
    ax.xaxis.set_major_locator(mdates.MonthLocator(bymonth=[2, 8]))  # x轴每3个月显示
    ax.set_xlim(left=all_data.index.min(), right=all_data.index.max())  # 设置x轴的限制
    # ax.set_xticks(all_cumulative_wealth.index)
    # ax.set_xticklabels(all_cumulative_wealth.index.strftime('%Y-%m'), rotation=45)
    plt.xlabel('Date')
    plt.ylabel('Cumulative Wealth')
    plt.legend(ncol=1, loc='upper left')
    plt.grid(False)
    plt.savefig('修正/改变CVaR的beta/ChangeCVaRBeta（折线图）.png',dpi=600)
    plt.close()

def Visualize_lambda_heat():
    folder_path = "修正/改变CVaR的beta/累积收益"
    files = [f for f in os.listdir(folder_path) if f.endswith('.xlsx')]
    folder_path_old = '/Users/yinmengzi/Desktop/工作1-代码/OLPS考虑交易成本/修正/改变CVaR的beta/累积收益'
    files_old = [f for f in os.listdir(folder_path_old) if f.endswith('.xlsx')]

    all_data = pd.DataFrame()  # 创建一个空的DataFrame来存储所有的数据
    for file in files_old:
        data = pd.read_excel(os.path.join(folder_path_old, file))
        lambda_value = float(file.split('beta')[-1].rstrip(')).xlsx')) # 从文件名中提取lambda的值
        all_data.loc[lambda_value,'MCRM Cumulative Wealth'] = data.iloc[-1]['累积收益']  # 将累积收益列添加到all_data DataFrame中，列名为lambda的值
    for file in files:
        data = pd.read_excel(os.path.join(folder_path, file))
        lambda_value = float(file.split('beta')[-1].rstrip(')).xlsx')) # 从文件名中提取lambda的值
        all_data.loc[lambda_value,'New MCRM Cumulative Wealth'] = data.iloc[-1]['累积收益']  # 将累积收益列添加到all_data DataFrame中，列名为lambda的值
    all_data = all_data.reindex(sorted(all_data.index, key=lambda x: x), axis=0)  # 对列进行排序，以确保图例的顺序按照数字顺序

    # 绘制热力图
    fig, ax = plt.subplots(figsize=(10, 4))
    sns.heatmap(all_data.T, annot=True, fmt=".4f", cmap='YlOrRd', ax=ax, cbar_kws={"shrink": 0.4, 'pad': 0.01})
    ax.set_xlabel('\u03B2', labelpad=5)
    ax.set_yticklabels(['DROPS-1','DROPS-2'],va='center',rotation=90)
    ax.xaxis.set_ticks_position('none')
    ax.yaxis.set_ticks_position('none')
    ax.set_aspect(1)
    #plt.title(f'Cumulative Wealth with \u03BB Changed')
    #plt.show()
    plt.savefig('修正/改变CVaR的beta/ChangeCVaRBeta.png',dpi=600)
    plt.close()

Visualize_lambda_line()
#Visualize_lambda_heat()
