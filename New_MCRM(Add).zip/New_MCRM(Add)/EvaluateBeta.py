import pandas as pd
import numpy as np
from scipy.optimize import minimize
import datetime
import os
import glob

def calculate_metrics(strategy_portfolio):
    risk_free_rate = 1
    cumulative_wealth = pd.read_excel(f"修正/改变CVaR的beta/累积收益/cumulative_wealth(TSDROPS(beta{strategy_portfolio})).xlsx")['累积收益']
    returns = cumulative_wealth.div(cumulative_wealth.shift())
    returns = returns.fillna(1)
    real_returns = returns - 1

    # 计算最大回撤（MDD）
    drawdowns = np.minimum(real_returns - 1, 0)  # 只考虑收益小于1的情况
    MDD = np.sqrt(np.mean(drawdowns ** 2))  # 根据公式计算MDD

    # 计算VaR
    confidence_level = 0.95
    VaR = - np.percentile(real_returns, 100*(1-confidence_level))

    # 计算CVaR
    CVaR = - np.mean(real_returns[real_returns < - VaR])

    # 计算超额收益
    excess_returns = returns - benchmark_returns

    # 计算Beta, Alpha
    Beta = returns.cov(benchmark_returns) / np.var(benchmark_returns)
    Alpha = np.mean(returns)- [risk_free_rate + Beta*(np.mean(benchmark_returns) - risk_free_rate)]

    # 计算夏普比率
    sharpe_ratio = (np.mean(returns) - risk_free_rate) / np.std(returns)

    # 计算信息比率
    information_ratio = np.mean(excess_returns) / np.std(excess_returns)

    # 计算卡玛比率
    calmar_ratio = (np.mean(returns) - risk_free_rate) / MDD

    # 计算特雷诺比率
    Treynor_ratio = (np.mean(returns) - risk_free_rate) / Beta

    # 计算M2比率
    M2_ratio =(np.mean(returns) - risk_free_rate) * (np.std(benchmark_returns) / np.std(returns)) - (np.mean(benchmark_returns) - risk_free_rate)

    return {
        '$beta$': strategy_portfolio,
        '$S_t$':float(list(cumulative_wealth)[-1]),
        'CVaR': CVaR,
        'MDD': MDD,
        'SR': sharpe_ratio,
        'TR': Treynor_ratio
    }

if __name__ == '__main__':
    #AverageAEC()
    # 获取每种策略的结果文件
    strategy_portfolio_files = [os.path.basename(file) for file in glob.glob(os.path.join('修正/改变CVaR的beta/累积收益', '*'))]
    strategy_portfolios = [file.split('beta')[-1].split(')')[0] for file in strategy_portfolio_files]

    returns_df = pd.read_excel("returns.xlsx") # 读取收益率数据
    returns_df.replace(0, np.nan, inplace=True)
    returns_df.bfill(inplace=True)

    all_cumulative_wealth = pd.DataFrame()  # 保存全部策略的累积收益
    for strategy in strategy_portfolios:
        cumulative_wealth_df = pd.read_excel(f'修正/改变CVaR的beta/累积收益/cumulative_wealth(TSDROPS(beta{strategy})).xlsx')
        cumulative_wealth_df.rename(columns={'累积收益': strategy}, inplace=True)
        if all_cumulative_wealth.empty:
            all_cumulative_wealth = cumulative_wealth_df
        else:
            all_cumulative_wealth = pd.merge(all_cumulative_wealth, cumulative_wealth_df, on='Date', how='left')

    all_cumulative_wealth.to_excel(f'修正/改变CVaR的beta/所有策略的累积收益.xlsx', index=False)

    # benchmark的每日收益向量
    cumulative_wealth = pd.read_excel(f"修正/累积收益/cumulative_wealth(BAH).xlsx")['累积收益']
    benchmark_returns = cumulative_wealth.div(cumulative_wealth.shift())

    # 计算每种策略的评价指标
    metrics_df = pd.DataFrame() # 保存全部策略的评价指标
    for strategy in strategy_portfolios:
        metrics = calculate_metrics(strategy)
        metrics_df = metrics_df.append(metrics, ignore_index=True)

    metrics_df.to_excel('修正/改变CVaR的beta/所有策略评估结果.xlsx', index=False)
