import numpy as np
import pandas as pd
import numpy as np
from scipy.optimize import minimize
import cvxpy as cp
import warnings
warnings.filterwarnings("ignore")
from BetterARIMA import arima_with_lagged_esg
import datetime
import os
import openpyxl

# 读取收益率数据
returns_df = pd.read_excel("returns.xlsx")
time_gap = returns_df.shape[1]
returns_df_index = returns_df.set_index("Stock")
#print(returns_df.columns[returns_df.shape[1]-1])
# 读取ESG得分数据
esg_df = pd.read_excel("esg.xlsx")
# 设置“Stock”列为索引
esg_df.set_index("Stock", inplace=True)

# 输入全部价格相对向量
m = len(returns_df)  # 股票数量
theta = 0.0005 # 交易成本率
s = 30 # 窗口大小
L = 0.1 # 控制求解进程
eta = 10 * theta # 平衡收益和成本

# 读取行业股票价格
industrial_stock_price = pd.read_excel("Industrial_StockPrice(2019.1.1-2023.10.9).xlsx")
df = pd.merge(returns_df, industrial_stock_price, left_on='Stock', right_on='Code')
industry_ids = df['industry_gics'].tolist() # 创建每个股票对应的的行业列表
returns_df_industry = returns_df
returns_df_industry['Industry'] = industry_ids # 将行业ID列表添加为新列

# 获取行业列表
initial_industry_portfolio_allocations = pd.read_excel('/Users/yinmengzi/Desktop/行业投资比例改进/轮盘赌+动态gamma/SCS/动态状态转移矩阵0-1/行业最优投资组合（NewMCRM）.xlsx') # 读取行业投资比例
industries = initial_industry_portfolio_allocations.iloc[:,0].tolist()

def OLPS(returns_df, portfolio_allocations, lambda_param):
    stock_order = {stock: i for i, stock in enumerate(returns_df['Stock'].unique())}
    b_tplus1_df = pd.DataFrame(columns=['Stock', '最优投资组合'])
    initial_date = returns_df.columns[returns_df.shape[1] - 31]  # 初始日期，和for t in range对应
    result_data = {'Industry': [], 'Stock': []}
    b_tplus1 = dict()
    b_tminus1 = dict()
    b_t = dict()
    for industry in industries:
        initial_industry_ratio = float(
            portfolio_allocations[portfolio_allocations['行业'] == industry][initial_date.strftime('%Y/%m')].iloc[
                0])  # 获取第二天行业比例
        initial_industry_ratios = [initial_industry_ratio / 5 for i in range(5)]
        b_tplus1[industry] = np.array(initial_industry_ratios)  # 存放t+1期的投资比例
        b_t[industry] = np.array(initial_industry_ratios)  # 存放t期的投资比例
        b_tminus1[industry] = np.array(initial_industry_ratios)  # 存放t-1期的投资比例
    b_tminus1_tilde = np.zeros(50)
    S_tminus1 = 1
    cumulative_wealth_df = pd.DataFrame(columns=['Date', '累积收益'])
    for t in range(time_gap - 1125, time_gap):  # 获取已知的数据（10-09之前的数据）
        all_b_t = []
        if t != time_gap - 1:
            all_stocks = []
        # 分别求每个行业中的股票的投资组合
        for industry in industries:
            b_tminus1_tilde_industry = []
            industry_stocks = returns_df.loc[returns_df_industry['Industry'] == industry, 'Stock']  # 当前行业所有股票
            date = returns_df.columns[t]  # t时刻的日期

            # print(date)
            if t != time_gap - 1:  # 如果不是最后一个
                b_t[industry] = b_tplus1[industry]  # 更新当前投资比例
                for bt in b_t[industry]:
                    all_b_t.append(bt)
                for stock in industry_stocks:
                    b_tminus1_tilde_industry.append(b_tminus1_tilde[stock_order[stock]])
                unique_stocks, b_tplus1[industry] = ARIMA_ESG_COST(industry, t, b_t, b_tminus1_tilde_industry, L,
                                                                   eta)  # 更新投资组合

                b_tminus1[industry] = b_t[industry]
                for stock in unique_stocks:
                    all_stocks.append(stock)

                # 输出
                print(f"{date}{industry}行业的投资组合为：{b_t[industry]}")

            else:  # 如果是最后一个，不需要再预测下一期，直接输出上一期的预测值
                # x_t = returns_df_every_industry.iloc[:, t]  # 所有股票t时刻的相对价格
                b_t = b_tplus1  # rebalance
                for bt in b_t[industry]:
                    all_b_t.append(bt)
                # 输出
                print(f"{date}{industry}行业的的投资组合为：{b_t[industry]}")
        b_tplus1_df = pd.concat([b_tplus1_df, pd.DataFrame({'Date': date, 'Stock': all_stocks, '最优投资组合': all_b_t})])
        b_tplus1_df['StockOrder'] = b_tplus1_df['Stock'].map(stock_order)
        b_tplus1_df.sort_values(by='StockOrder', inplace=True)
        b_tplus1_df.drop(columns='StockOrder', inplace=True)
        all_b_t = np.array(b_tplus1_df.loc[b_tplus1_df['Date'] == date, '最优投资组合'])

        # 解交易成本k的目标函数
        def objective_function(k):
            l1_norm = np.sum(np.abs(b_tminus1_tilde - all_b_t * k))
            return 1 - k - theta * l1_norm

        constraint = ({'type': 'ineq',
                       'fun': lambda k: 1e-20 - np.abs(1 - k - theta * np.sum(np.abs(b_tminus1_tilde - all_b_t * k)))})
        k = minimize(objective_function, 1, bounds=[(0, 1)], constraints=constraint).x
        x_t = returns_df.iloc[:, t]  # 所有股票t时刻的相对价格
        s_t = S_tminus1 * k * (np.dot(all_b_t.T, x_t))  # 考虑成本损失的累计收益
        S_tminus1 = s_t
        b_tminus1_tilde = all_b_t * x_t / (np.dot(all_b_t.T, x_t))
        cumulative_wealth_df = cumulative_wealth_df.append({'Date': date, '累积收益': s_t[0]}, ignore_index=True)

    cumulative_wealth_df.to_excel(f"修正/改变轮盘赌lambda动态状态转移矩阵0-1的累积收益/cumulative_wealth_lambda_{lambda_param}.xlsx", index=False)
    b_tplus1_df = b_tplus1_df.pivot(index='Stock', columns='Date', values='最优投资组合').reset_index()
    stock_order = {stock: i for i, stock in enumerate(returns_df['Stock'].unique())}
    b_tplus1_df['StockOrder'] = b_tplus1_df['Stock'].map(stock_order)
    b_tplus1_df.sort_values(by='StockOrder', inplace=True)
    b_tplus1_df.drop(columns='StockOrder', inplace=True)
    b_tplus1_df.reset_index(drop=True).to_excel(f'修正/改变轮盘赌lambda动态状态转移矩阵0-1的投资组合/MyAEC_lambda_{lambda_param}.xlsx', index=False)
    #print(b_tplus1_df)
    return b_tplus1_df

def ARIMA_ESG_COST(industry, t, b_t, b_t_tilde, L, eta):
    if t != time_gap-2:
       date = returns_df.columns[t+1] # t+1日（预测日）的日期
    else: #09-28日的预测下一日取9月的行业比例
       date = datetime.datetime.strptime('2023-09',"%Y-%m")
       #print(date)

    date_last = returns_df.columns[t]  # t日的日期

    industry_ratio_last = float(industry_portfolio_allocations[industry_portfolio_allocations['行业'] == industry][date_last.strftime('%Y/%m')].iloc[0]) # 获取当日的行业比例
    industry_ratio = float(industry_portfolio_allocations[industry_portfolio_allocations['行业'] == industry][date.strftime('%Y/%m')].iloc[0]) # 获取预测日的行业比例
    unique_stocks = list(set(returns_df_industry.loc[returns_df_industry['Industry'] == industry, 'Stock'].tolist())) # 获取属于当前行业的股票代码
    #print(industry_ratio)
    # 当月第一个阶段比例为0，则直接赋值0
    if industry_ratio == 0:
        b_tplus1 = np.zeros(5)
    # 第一阶段比例不为0，则进行下一阶段计算
    else:
        # 获取预测的t+1日相对价格
        x_tplus1_predict = []

        for stock in unique_stocks:
            returns = returns_df_index.loc[stock][t - s: t]  # 当前股票的收益率历史数据
            esg_scores = esg_df.loc[stock].loc[returns.index]  # 当前股票的ESG历史数据

            model_fit, predict = arima_with_lagged_esg(stock, returns, esg_scores, t + 1, s)
            # 如果预测值为空，使用最后一个收益率作为预测值
            if np.isnan(predict):
                predict = returns.iloc[-1]

            x_tplus1_predict.append(predict)

        x_tplus1_predict_replace = []
        for i in range(len(x_tplus1_predict)):
            if x_tplus1_predict[i] >= 2:
                print(f"{date}的预测收益大于2，为{x_tplus1_predict}")
                if i == len(x_tplus1_predict) - 1:
                    x_tplus1_predict_replace.append(x_tplus1_predict[i - 1])
                elif i == 0:
                    x_tplus1_predict_replace.append(x_tplus1_predict[i + 1])
                else:
                    x_tplus1_predict_replace.append((x_tplus1_predict[i + 1] + x_tplus1_predict[i - 1]) / 2)
                print(f"修正后为：{x_tplus1_predict_replace}")
            else:
                x_tplus1_predict_replace.append(x_tplus1_predict[i])
        x_tplus1_predict = np.array(x_tplus1_predict_replace)
        # print(x_tplus1_predict)

        # 更新t+1期的投资组合
        industry_x_t = np.array(returns_df[returns_df_industry['Industry'] == industry].iloc[:, t])
        all_x_t = np.array(returns_df.iloc[:, t])
        all_b_t = []
        for value in b_t.values():
            for v in value:
                all_b_t.append(v)
        all_b_t = np.array(all_b_t)
        # z = b_t_tilde + x_tplus1_predict / (L * b_t_tilde.T * x_tplus1_predict) - np.ones(5).T * x_tplus1_predict * np.ones(5)/(5 * L * b_t_tilde.T * x_tplus1_predict) - np.ones(5) * (industry_ratio_last - industry_ratio)/5
        z = b_t_tilde + x_tplus1_predict / L - np.ones(5).T * x_tplus1_predict * np.ones(5) / (5 * L) - np.ones(5) * (
                    (b_t[industry] * industry_x_t) / np.dot(all_b_t, all_x_t) - industry_ratio) / 5
        b_tplus1 = z + np.sign(z) * np.maximum(0, np.abs(z) - eta / L)

        # 将计算出来的portfolio投影到限制条件约束的可行域中
        b = cp.Variable(5)

        b_tplus1 = [np.maximum(i, 1e-30) for i in b_tplus1]
        b_tplus1 = [np.minimum(i, 1e+30) for i in b_tplus1]

        # print(b_tplus1)
        # print(industry_ratio)
        objective = cp.Minimize(cp.sum_squares(b - b_tplus1))
        constraints = [b >= 0,
                       cp.sum(b) <= industry_ratio]

        prob = cp.Problem(objective, constraints)
        prob.solve(verbose=False)
        # print(b.value)
        b_value = b.value
        b_value[b_value < 0] = 0
        b_value[np.isnan(b_value)] = 0
        b_value[b_value > industry_ratio] = industry_ratio

        b_tplus1 = np.array(b.value)  # 获得最后的portfoiio解

    return unique_stocks, b_tplus1

for count in range(20,25):
    industry_portfolio_allocations = pd.read_excel(f'/Users/yinmengzi/Desktop/行业投资比例改进/轮盘赌+动态gamma/SCS/动态状态转移矩阵0-1/测试轮盘赌/{count}.行业最优投资组合（NewMCRM）.xlsx') # 读取行业投资比例
    industry_portfolio_allocations.rename(columns={'Unnamed: 0': '行业'}, inplace=True) # 将第一列的列名改为'行业'

    portfolio_allocation = OLPS(returns_df, industry_portfolio_allocations, count)
    '''
    portfolio_allocation.columns = [col if isinstance(col, datetime.datetime) or col == 'Stock' else datetime.datetime.strptime(col, '%Y/%m/%d') for col in portfolio_allocation.columns]
    cumulative_time = portfolio_allocation.shape[1]

    cumulative_wealth_df = pd.DataFrame(columns=['Date', '累积收益'])  # 存每天的累积收益
    k_df = pd.DataFrame(columns=['Date', 'k'])  # 存每天的真实资产比例
    S_tminus1 = 1

    cumulative_wealth_df = cumulative_wealth_df.append({'Date': portfolio_allocation.columns[1], '累积收益': S_tminus1}, ignore_index=True)

    for t in range(2, cumulative_time):  # 遍历每个交易日
        date = portfolio_allocation.columns[t]  # t时刻的日期
        x_t = returns_df.loc[:, date]  # 所有股票t时刻的相对价格

        b_t = portfolio_allocation.iloc[:, t]  # 所有股票t时刻的分配比例
        b_tminus1 = portfolio_allocation.iloc[:, t - 1]  # 所有股票t-1时刻的分配比例

        # 解交易成本k的目标函数
        def objective_function(k, b_tminus1, b_t, theta):
            l1_norm = np.sum(np.abs(b_tminus1 - b_t * k))
            return 1 - k - theta * l1_norm

        k = minimize(objective_function, 1, args=(b_tminus1, b_t, theta), bounds=[(0, 1)]).x  # 考虑交易成本，实际资产比例
        s_t = S_tminus1 * k * (np.dot(b_t.T, x_t))  # 考虑成本损失的累计收益
        S_tminus1 = s_t

        print(f"{date}的累积财富为:{s_t[0]}")
        cumulative_wealth_df = cumulative_wealth_df.append({'Date': date, '累积收益': s_t[0]}, ignore_index=True)
    
    cumulative_wealth_df.to_excel(f"改变轮盘赌lambda动态状态转移矩阵0-1的累积收益/cumulative_wealth_lambda_{count}.xlsx", index=False)
    '''