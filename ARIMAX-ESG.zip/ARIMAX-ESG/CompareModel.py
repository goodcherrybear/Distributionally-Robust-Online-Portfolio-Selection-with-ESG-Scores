import pandas as pd
import matplotlib.pyplot as plt
from sklearn.metrics import mean_squared_error, mean_absolute_error
import numpy as np

# 计算评价指标的函数
def calculate_metrics(y_true, y_pred):
    mse = mean_squared_error(y_true, y_pred)
    rmse = np.sqrt(mse)
    mae = mean_absolute_error(y_true, y_pred)
    mape = np.mean(np.abs((y_true - y_pred) / y_true))

    return mse, rmse, mae, mape

# 读取数据
df = pd.read_excel(f"50Stock_ARIMA_results.xlsx")

# 获取所有的股票代码
stocks = df['Stock'].unique()

# 创建一个空的数据框来保存评价指标
df_metrics = pd.DataFrame(columns=['Stock', 'Method', 'MSE', 'RMSE', 'MAE', 'MAPE'])


# 对每只股票分别计算评价指标
for stock in stocks:
    df_stock = df[df['Stock'] == stock]
    metrics_esg = calculate_metrics(df_stock['Return'], df_stock['ARIMA_ESG_Forecast'])
    metrics_no_esg = calculate_metrics(df_stock['Return'], df_stock['ARIMA_No_ESG_Forecast'])
    metrics_new_esg = calculate_metrics(df_stock['Return'], df_stock['ARIMA_New_EGS_Forecast'])
    df_metrics = df_metrics.append([
        {'Stock': stock, 'Method': 'ARIMA_ESG_Forecast', 'MSE': metrics_esg[0], 'RMSE': metrics_esg[1], 'MAE': metrics_esg[2], 'MAPE': metrics_esg[3]},
        {'Stock': '', 'Method': 'ARIMA_No_ESG_Forecast', 'MSE': metrics_no_esg[0], 'RMSE': metrics_no_esg[1], 'MAE': metrics_no_esg[2], 'MAPE': metrics_no_esg[3]},
        {'Stock': '', 'Method': 'ARIMA_New_EGS_Forecast', 'MSE': metrics_new_esg[0], 'RMSE': metrics_new_esg[1], 'MAE': metrics_new_esg[2], 'MAPE': metrics_new_esg[3]}
    ], ignore_index=True)

df_metrics.to_excel('3Model_performance.xlsx', index=False)

df_metrics = pd.read_excel('3Model_performance.xlsx')

# 创建一个空的数据框来保存统计结果
df_count = pd.DataFrame(columns=['Method', 'MSE', 'RMSE', 'MAE', 'MAPE'])

# 对每种方法分别统计在每个评估指标下表现最好的股票数量
for method in ['ARIMA_ESG_Forecast', 'ARIMA_No_ESG_Forecast', 'ARIMA_New_EGS_Forecast']:
    df_method = df_metrics[df_metrics['Method'] == method]
    best_methods_index = df_metrics.groupby('Stock')[['MSE', 'RMSE', 'MAE', 'MAPE']].idxmin()
    for metric in ['MSE', 'RMSE', 'MAE', 'MAPE']:
        best_methods = df_metrics.loc[best_methods_index[metric]]['Method']
        count = sum(df_method.reset_index()['Method'] == best_methods.reset_index()['Method'])
        df_count.loc[method, metric] = count

df_count.reset_index().rename(columns={'index': 'Method'}).to_excel('3Model_performance_statistics.xlsx', index=False)

# 计算每种方法五个指标的平均值
df_metrics_mean = df_metrics.groupby('Method').mean()
df_metrics_mean.to_excel('3Model_performance_mean.xlsx')
