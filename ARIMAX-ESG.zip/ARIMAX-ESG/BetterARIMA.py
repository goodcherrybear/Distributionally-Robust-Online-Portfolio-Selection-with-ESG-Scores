# 窗口大小s=30, 考虑ESG得分为外生变量的改进ARIMA vs 不考虑EGS的原始ARIMA 预测股价
# 考虑ESG的原始ARIMA(系数*t时刻外生变量) vs 考虑ESG的改进ARIMA(系数*t-l时刻外生变量+系数*t时刻外生变量变化率)
import pandas as pd
import numpy as np
import matplotlib.pyplot as plt
from statsmodels.tsa.arima.model import ARIMA
from statsmodels.tsa.stattools import acf, pacf
from sklearn.metrics import mean_squared_error
import seaborn as sns
import matplotlib.dates as mdates
import pmdarima as pm
import warnings
warnings.filterwarnings("ignore")

# 读取收益率数据
returns_df = pd.read_excel("/Users/yinmengzi/Desktop/ARIMA改进/returns.xlsx")
# 设置“Stock”列为索引
returns_df.set_index("Stock", inplace=True)

# 读取ESG得分数据
esg_df = pd.read_excel("/Users/yinmengzi/Desktop/ARIMA改进/esg.xlsx")
# 设置“Stock”列为索引
esg_df.set_index("Stock", inplace=True)

def calculate_pqd_values(t,returns,s):
    d = pm.arima.ndiffs(returns, test='adf')

    # 计算ACF和PACF
    acf_values = acf(returns, nlags=int(s / 2) - 1)
    pacf_values = pacf(returns, nlags=int(s / 2) - 1)

    # 自动选择p和q值
    p = q = None
    for i in range(1, int(s / 2) - 1):
        if acf_values[i] < 0.05 and acf_values[i + 1] < acf_values[i]:
            p = i
            break

    for i in range(1, int(s / 2) - 1):
        if pacf_values[i] < 0.05 and pacf_values[i + 1] < pacf_values[i]:
            q = i
            break

    if p  == None:
        p = 0
    if q == None:
        q = 0

    return p, d, q

# 原始ARIMA，考虑ESG
def arima_with_esg(stock_code, returns, esg_scores, t, s):
    # 计算合适的p、d和q值
    p, d, q = calculate_pqd_values(t, returns, s)

    # 构建ARIMA模型，传递ESG得分作为外生变量
    model = ARIMA(returns, order=(p, d, q), exog=esg_scores, trend='n',enforce_stationarity=False,enforce_invertibility=False)
    model_fit = model.fit()

    # 预测收益率
    forecast = model_fit.forecast(steps=1, exog=esg_df.loc[stock_code][t-1])

    return model_fit, forecast.iloc[0]

# 原始ARIMA，不考虑ESG
def arima_without_esg(stock_code, returns, t, s):
    # 计算合适的p、d和q值
    p, d, q = calculate_pqd_values(t, returns, s)

    # 构建ARIMA模型
    model = ARIMA(returns, order=(p, d, q),enforce_stationarity=False,enforce_invertibility=False)
    model_fit = model.fit()

    # 预测收益率
    forecast = model_fit.forecast(steps=1)

    return model_fit, forecast.iloc[0]

# 改进ARIMA，考虑ESG
def arima_with_lagged_esg(stock_code, returns, esg_scores, t, s):
    # 获取全数据范围内的ESG得分数据
    esg_data = esg_df.loc[stock_code]
    #print(returns)
    # 计算合适的p、d和q值
    p, d, q = calculate_pqd_values(t, returns, s)

    # 计算ESG得分的滞后期数，使用最大交叉相关性的滞后期数
    cross_correlation = np.correlate(returns, esg_scores, mode='full')
    max_correlation_index = np.argmax(cross_correlation)
    lag_for_esg = max_correlation_index - (len(returns) - 1)
    #print(f"滞后阶数：{lag_for_esg}")

    # 计算ESG得分的滞后
    esg_lagged = esg_data.shift(lag_for_esg)

    # 计算ESG得分变化率
    esg_diff = esg_data.diff()
    esg_data = pd.concat([esg_data[t-s-1:t], esg_lagged[t-s-1:t], esg_diff[t-s-1:t]], axis=1)

    # 构建ARIMA模型，传递滞后的ESG得分作为外生变量
    '''
    #print(returns_df.shape[1]-1)
    if t <= returns_df.shape[1]:
        print(returns)
        print(esg_data)
        model = ARIMA(returns, order=(p, d, q), exog=esg_data, trend='n',enforce_stationarity=False, enforce_invertibility=False)
    else:
        print(returns)
        print(esg_data)
        model = ARIMA(returns, order=(p, d, q), exog=esg_data, trend='n', enforce_stationarity=False,enforce_invertibility=False)
    '''

    model = ARIMA(returns, order=(p, d, q), exog=esg_data[:-1], trend='n', enforce_stationarity=False,enforce_invertibility=False)
    model_fit = model.fit()

    # 预测收益率
    forecast = model_fit.forecast(steps=1, exog=esg_data.iloc[-1])
    '''
    if forecast.iloc[0] > 2:
        print(f"forecast为：{forecast.iloc[0]}")
        print(esg_data)
        print(returns)
        print(model_fit)
    print(f"forecast为：{forecast.iloc[0]}")
    '''
    return model_fit, forecast.iloc[0]

def calculate_rmse(true_returns, forecasts):
    # 找到 forecasts 和 true_returns 中不包含 NaN 的索引
    valid_indices = ~np.isnan(np.array(forecasts))
    # 使用有效索引来过滤数据
    valid_true_returns = list(np.array(true_returns)[valid_indices])
    valid_forecasts = list(np.array(forecasts)[valid_indices])
    rmse = np.sqrt(mean_squared_error(valid_true_returns, valid_forecasts))
    return rmse

# 可视化性能对比（箱线图）
def visualize_performance(results_df,s):
    plt.figure(figsize=(10, 6))
    sns.boxplot(data=results_df[['No_ESG_RMSE', 'New_EGS_RMSE']])
    plt.xlabel('模型')
    plt.ylabel('RMSE')
    plt.title('不考虑ESG的原始ARIMA vs 考虑ESG的改进ARIMA')
    plt.savefig(f"最终50只股票/ARIMA_performance_comparison1.png")
    plt.close()

    plt.figure(figsize=(10, 6))
    sns.boxplot(data=results_df[['ESG_RMSE', 'New_EGS_RMSE']])
    plt.xlabel('模型')
    plt.ylabel('RMSE')
    plt.title('考虑ESG的原始ARIMA vs 考虑ESG的改进ARIMA')
    plt.savefig(f"最终50只股票/ARIMA_performance_comparison2.png")
    plt.close()

def main():
    max_num_stocks = len(returns_df)  # 最大处理的股票数量
    #max_num_stocks = 11
    s = 30 # 窗口大小
    results = []
    i = 1 # 记录运行情况
    all_results = []  # 用于存储所有股票的预测结果
    models = []  # 用于存储模型

    while i <= max_num_stocks:
        stock_code = returns_df.index[i - 1]
        returns = returns_df.loc[stock_code]

        print(f"第{i}只股票开始预测")
        # 对每个时间t进行预测
        esg_forecasts = []
        no_esg_forecasts = []
        new_esg_forecasts = []
        true_returns = []

        for t in range(32, len(returns)):
            # 获取t之前30天的收益率和ESG
            returns_history = returns[t - s :t]
            returns_history.replace(0, np.nan, inplace=True)
            returns_history = returns_history.dropna()
            esg_history = esg_df.loc[stock_code].loc[returns_history.index]

            # 预测时间t的收益率（考虑ESG）
            try:
                esg_forecast = arima_with_esg(stock_code, returns_history, esg_history, t, s)
            except Exception as e:
                print(f"在{stock_code}的第{t}时间点出现异常: {str(e)}")
                esg_forecast = np.nan  # 设置为空值
            esg_forecasts.append(esg_forecast)

            # 预测时间t的收益率（不考虑ESG）
            try:
                no_esg_forecast = arima_without_esg(stock_code, returns_history, t, s)
            except Exception as e:
                print(f"在{stock_code}的第{t}时间点出现异常: {str(e)}")
                no_esg_forecast = np.nan  # 设置为空值
            no_esg_forecasts.append(no_esg_forecast)

            # 改进ARIMA，预测时间t的收益率（考虑ESG）
            try:
                model_fit, new_esg_forecast = arima_with_lagged_esg(stock_code, returns_history, esg_history, t, s)
            except Exception as e:
                print(f"在{stock_code}的第{t}时间点出现异常: {str(e)}")
                new_esg_forecast = np.nan  # 设置为空值
            new_esg_forecasts.append(new_esg_forecast)

            # 记录真实收益率
            true_return = returns[t]
            true_returns.append(true_return)
            print(f"{t}时间的真实值为{true_return}")
            print(f"{t}时间的预测值（考虑esg）为{esg_forecast}")
            print(f"{t}时间的预测值（不考虑esg）为{no_esg_forecast}")
            print(f"{t}时间的预测值（考虑esg，改进ARIMA）为{new_esg_forecast}")

        # 计算RMSE
        esg_rmse = calculate_rmse(true_returns, esg_forecasts)
        no_esg_rmse = calculate_rmse(true_returns, no_esg_forecasts)
        new_esg_rmse = calculate_rmse(true_returns, new_esg_forecasts)

        results.append({
            'Stock': stock_code,
            'ESG_RMSE': esg_rmse,
            'No_ESG_RMSE': no_esg_rmse,
            'New_EGS_RMSE': new_esg_rmse
        })

        # 存储每只股票的预测结果
        all_results.append({
            'Stock': stock_code,
            'Date_True': returns.index[32:],
            'Return': returns[32:],
            'ARIMA_ESG_Forecast': esg_forecasts,
            'ARIMA_No_ESG_Forecast': no_esg_forecasts,
            'ARIMA_New_EGS_Forecast': new_esg_forecasts
        })
        '''
        # 判断满足两个条件的股票
        if (new_esg_rmse < no_esg_rmse) and (new_esg_rmse < esg_rmse):
            # 保存模型
            models.append(model_fit)
        '''
        #models.append(model_fit)
        model_fit.save(f"最终50只股票/已训练的ARIMA模型/stock_{stock_code}_model.pkl")
        # 可视化每只股票的预测结果
        plt.figure(figsize=(12, 6))
        plt.plot(returns.index[32:], returns[32:], label='真实值', marker='o')
        plt.plot(returns.index[32:], esg_forecasts,label='ARIMA预测（考虑ESG）', color='red')
        plt.plot(returns.index[32:], no_esg_forecasts, label='ARIMA预测（不考虑ESG）', color='green')
        plt.plot(returns.index[32:], new_esg_forecasts, label='改进的ARIMA预测（考虑ESG）', color='yellow')
        plt.xlabel('日期')
        plt.ylabel('收益率')
        plt.gca().xaxis.set_major_formatter(mdates.DateFormatter("%Y-%m-%d"))
        plt.title(f'{stock_code}[RMSE: {esg_rmse:.4f}(esg), {no_esg_rmse:.4f}(no esg), {new_esg_rmse:.4f}(new ARIMA)]')
        plt.legend()
        plt.savefig(f"New_ARIMA_{stock_code}.png")
        plt.close()

        print(f"窗口大小为{str(s)}的第{i}只股票完成预测")
        print(f"考虑esg的模型RMSE为：{esg_rmse}")
        print(f"不考虑esg的模型RMSE为：{no_esg_rmse}")
        print(f"考虑esg的改进模型RMSE为：{new_esg_rmse}")
        print("="*20)

        i += 1

    # 创建结果DataFrame
    results_df = pd.DataFrame(results)

    # 保存结果到Excel文件
    results_df.to_excel(f"最终50只股票/arima_results.xlsx", index=False)

    # 可视化性能对比
    visualize_performance(results_df,s)

     # 将所有股票的预测结果保存到一个Excel文件
    all_results_df = pd.concat([pd.DataFrame(result) for result in all_results], ignore_index=True)
    all_results_df.to_excel(f"最终50只股票/all_arima_results.xlsx", index=False)
    '''
    # 筛选出满足条件的股票
    selected_stocks = results_df[(results_df['New_EGS_RMSE'] < results_df['No_ESG_RMSE']) & (results_df['New_EGS_RMSE'] < results_df['ESG_RMSE'])]

    # 保存满足条件的股票的性能到Excel文件
    selected_stocks.to_excel(f"{s}_selected_stocks_performance.xlsx", index=False)
    '''
    # 保存模型
    #for idx, model_fit in enumerate(models):
    #    model_fit.save(f"最终50只股票/已训练的ARIMA模型/stock_{idx}_model.pkl")

if __name__ == "__main__":
    main()
